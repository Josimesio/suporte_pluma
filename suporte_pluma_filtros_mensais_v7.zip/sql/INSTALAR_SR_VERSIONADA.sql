-- INSTALAÇÃO COMPLETA V11. Execute TODO o arquivo.
begin;
-- INSTALAÇÃO COMPLETA V9. Execute TODO o arquivo no SQL Editor.
-- Administrador/Gestor editam; demais usuários consultam e exportam.

-- Execute no projeto Supabase usado pelo portal SUPORTE ORACLE.
-- Pré-requisito: public.perfis_usuarios já utilizado pelo login do site.
-- A v9 adiciona auditoria aos chamados e limita a escrita a Administrador/Gestor.
-- Os perfis, dados existentes e permissões de consulta são preservados.

do $$
begin
  if to_regclass('public.perfis_usuarios') is null then
    raise exception 'Projeto incorreto: public.perfis_usuarios não foi encontrada.';
  end if;
end;
$$;

create schema if not exists sr_planilha_interno;

create table if not exists public.sr_planilha_registros (
  id uuid primary key default gen_random_uuid(),
  origem_revisao text not null,
  linha_origem text not null,
  numero_sr text not null check (length(btrim(numero_sr)) > 0),
  valores jsonb not null check (jsonb_typeof(valores) = 'array' and jsonb_array_length(valores) = 25),
  aging_calculado boolean not null default false,
  versao integer not null default 1 check (versao > 0),
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  atualizado_por uuid,
  unique (origem_revisao, linha_origem)
);

create table if not exists public.sr_planilha_versoes (
  id uuid primary key default gen_random_uuid(),
  registro_id uuid not null references public.sr_planilha_registros(id) on delete restrict,
  versao integer not null check (versao > 0),
  valores jsonb not null check (jsonb_typeof(valores) = 'array' and jsonb_array_length(valores) = 25),
  alteracoes jsonb not null default '[]'::jsonb check (jsonb_typeof(alteracoes) = 'array'),
  acao text not null check (acao in ('carga_inicial', 'edicao')),
  usuario_id uuid references auth.users(id) on delete set null,
  usuario_email text,
  alterado_em timestamptz not null default now(),
  unique (registro_id, versao)
);

create index if not exists sr_planilha_numero_idx on public.sr_planilha_registros(numero_sr);
create index if not exists sr_planilha_atualizado_por_idx on public.sr_planilha_registros(atualizado_por);
create index if not exists sr_planilha_versoes_usuario_idx on public.sr_planilha_versoes(usuario_id);

-- Consulta apenas do próprio perfil. Nunca usa user_metadata para autorizar.
create or replace function sr_planilha_interno.pode_consultar()
returns boolean language sql stable security invoker set search_path = ''
as $$
  select exists (
    select 1 from public.perfis_usuarios p
    where p.id = (select auth.uid()) and p.ativo is true
      and (p.perfil = 'administrador'
        or p.permissoes ->> 'inicio' = 'true'
        or p.permissoes ->> 'chamados_2025' = 'true'
        or p.permissoes ->> 'chamados_2026' = 'true')
      and (coalesce(p.mfa_obrigatorio, false) is false or (select auth.jwt() ->> 'aal') = 'aal2')
  );
$$;

create or replace function sr_planilha_interno.pode_editar()
returns boolean language sql stable security invoker set search_path = ''
as $$
  select exists (
    select 1 from public.perfis_usuarios p
    where p.id = (select auth.uid()) and p.ativo is true and p.perfil = 'administrador'
      and (coalesce(p.mfa_obrigatorio, false) is false or (select auth.jwt() ->> 'aal') = 'aal2')
  );
$$;

alter table public.sr_planilha_registros enable row level security;
alter table public.sr_planilha_versoes enable row level security;

drop policy if exists sr_planilha_consulta on public.sr_planilha_registros;
create policy sr_planilha_consulta on public.sr_planilha_registros for select to authenticated
using ((select sr_planilha_interno.pode_consultar()));

drop policy if exists sr_planilha_edicao on public.sr_planilha_registros;
create policy sr_planilha_edicao on public.sr_planilha_registros for update to authenticated
using ((select sr_planilha_interno.pode_editar()))
with check ((select sr_planilha_interno.pode_editar()));

drop policy if exists sr_planilha_historico_consulta on public.sr_planilha_versoes;
create policy sr_planilha_historico_consulta on public.sr_planilha_versoes for select to authenticated
using ((select sr_planilha_interno.pode_consultar()));

-- Valores e metadados são validados também em atualizações diretas autorizadas.
create or replace function sr_planilha_interno.validar_registro()
returns trigger language plpgsql security invoker set search_path = ''
as $$
declare
  i integer;
begin
  if jsonb_typeof(new.valores) <> 'array' or jsonb_array_length(new.valores) <> 25 then
    raise exception 'O registro deve conter os 25 campos da SR.';
  end if;
  for i in 0..24 loop
    if jsonb_typeof(new.valores -> i) not in ('string', 'number', 'boolean', 'null') then
      raise exception 'Campo % com tipo inválido.', i;
    end if;
  end loop;
  if btrim(new.valores ->> 2) is distinct from new.numero_sr then
    raise exception 'O número da SR não pode ser alterado.';
  end if;
  if tg_op = 'UPDATE' then
    if auth.uid() is null or not sr_planilha_interno.pode_editar() then
      raise exception using errcode = '42501', message = 'Somente administradores ativos podem editar a SR.';
    end if;
    if new.id is distinct from old.id or new.origem_revisao is distinct from old.origem_revisao
      or new.linha_origem is distinct from old.linha_origem or new.numero_sr is distinct from old.numero_sr
      or new.aging_calculado is distinct from old.aging_calculado or new.criado_em is distinct from old.criado_em
      or new.valores -> 2 is distinct from old.valores -> 2 then
      raise exception 'A identificação e a origem da SR permanecem fixas.';
    end if;
    if old.aging_calculado and new.valores -> 9 is distinct from old.valores -> 9 then
      raise exception 'Aging é calculado e não pode ser editado nesta linha.';
    end if;
    if new.valores = old.valores then return null; end if;
    new.versao := old.versao + 1;
  else
    new.versao := 1;
  end if;
  new.atualizado_em := clock_timestamp();
  new.atualizado_por := auth.uid();
  return new;
end;
$$;

-- SECURITY DEFINER é usado somente pelo gatilho privado para inserir na trilha
-- imutável. O cliente não recebe INSERT/UPDATE/DELETE na tabela de versões.
-- Sem EXECUTE para clientes, sem SQL dinâmico e com search_path fixo.
create or replace function sr_planilha_interno.registrar_versao()
returns trigger language plpgsql security definer set search_path = ''
as $$
declare
  diferencas jsonb := '[]'::jsonb;
  email_autor text;
  i integer;
begin
  if tg_op = 'UPDATE' and (auth.uid() is null or new.atualizado_por is distinct from auth.uid()) then
    raise exception using errcode = '42501', message = 'Autor da alteração inválido.';
  end if;
  if auth.uid() is not null then
    select p.email into email_autor from public.perfis_usuarios p where p.id = auth.uid() and p.ativo is true;
    if not found then raise exception using errcode = '42501', message = 'Perfil ativo não encontrado.'; end if;
  end if;
  if tg_op = 'UPDATE' then
    for i in 0..24 loop
      if new.valores -> i is distinct from old.valores -> i then
        diferencas := diferencas || jsonb_build_array(jsonb_build_object(
          'coluna', i, 'anterior', old.valores -> i, 'novo', new.valores -> i));
      end if;
    end loop;
  end if;
  insert into public.sr_planilha_versoes(registro_id, versao, valores, alteracoes, acao, usuario_id, usuario_email, alterado_em)
  values(new.id, new.versao, new.valores, diferencas,
    case when tg_op = 'INSERT' then 'carga_inicial' else 'edicao' end,
    auth.uid(), email_autor, new.atualizado_em);
  return new;
end;
$$;

drop trigger if exists sr_planilha_validar on public.sr_planilha_registros;
create trigger sr_planilha_validar before insert or update on public.sr_planilha_registros
for each row execute function sr_planilha_interno.validar_registro();

drop trigger if exists sr_planilha_versionar on public.sr_planilha_registros;
create trigger sr_planilha_versionar after insert or update on public.sr_planilha_registros
for each row execute function sr_planilha_interno.registrar_versao();

-- O bloqueio e a versão esperada impedem que um editor sobrescreva uma versão
-- salva por outro. UPDATE + histórico são confirmados na mesma transação.
create or replace function public.salvar_sr_planilha(
  p_registro_id uuid, p_versao_atual integer, p_alteracoes jsonb
)
returns public.sr_planilha_registros
language plpgsql security invoker set search_path = ''
as $$
declare
  registro public.sr_planilha_registros;
  novos_valores jsonb;
  item record;
  coluna integer;
begin
  if auth.uid() is null or not sr_planilha_interno.pode_editar() then
    raise exception using errcode = '42501', message = 'Somente administradores ativos podem editar a SR.';
  end if;
  if p_alteracoes is null or jsonb_typeof(p_alteracoes) <> 'object' or p_alteracoes = '{}'::jsonb then
    raise exception 'Informe os campos alterados.';
  end if;
  select * into registro from public.sr_planilha_registros where id = p_registro_id for update;
  if not found then raise exception 'Registro não encontrado ou sem permissão de acesso.'; end if;
  if p_versao_atual is null or registro.versao <> p_versao_atual then
    raise exception using errcode = 'P0001', message = 'Conflito de versão. Outra pessoa alterou esta linha. Recarregue e revise seus rascunhos antes de salvar.';
  end if;
  novos_valores := registro.valores;
  for item in select * from jsonb_each(p_alteracoes) loop
    if item.key !~ '^(0|[1-9]|1[0-9]|2[0-4])$' then raise exception 'Coluna inválida.'; end if;
    coluna := item.key::integer;
    if coluna = 2 or (coluna = 9 and registro.aging_calculado) then raise exception 'Campo fixo ou calculado.'; end if;
    if jsonb_typeof(item.value) not in ('string', 'number', 'boolean', 'null') then raise exception 'Tipo de valor inválido.'; end if;
    novos_valores := jsonb_set(novos_valores, array[item.key], item.value, false);
  end loop;
  if novos_valores = registro.valores then return registro; end if;
  update public.sr_planilha_registros set valores = novos_valores where id = p_registro_id returning * into registro;
  return registro;
end;
$$;

revoke all on public.sr_planilha_registros, public.sr_planilha_versoes from public, anon, authenticated;
grant select on public.sr_planilha_registros, public.sr_planilha_versoes to authenticated;
grant update(valores) on public.sr_planilha_registros to authenticated;
grant usage on schema sr_planilha_interno to authenticated;
revoke execute on function sr_planilha_interno.pode_consultar(), sr_planilha_interno.pode_editar(),
  sr_planilha_interno.validar_registro(), sr_planilha_interno.registrar_versao() from public, anon, authenticated;
grant execute on function sr_planilha_interno.pode_consultar(), sr_planilha_interno.pode_editar() to authenticated;
revoke execute on function public.salvar_sr_planilha(uuid, integer, jsonb) from public, anon, authenticated;
grant execute on function public.salvar_sr_planilha(uuid, integer, jsonb) to authenticated;

comment on table public.sr_planilha_registros is 'Estado atual das linhas da planilha SR; repetições de número SR preservadas pela linha de origem.';
comment on table public.sr_planilha_versoes is 'Histórico de versões da SR. Somente gatilhos do banco gravam a trilha de alterações.';

notify pgrst, 'reload schema';

-- V9: Administrador/Gestor, autoria e datas por campo.
-- Projeto do portal: vsnvhaojeiegzfrfvmps.
-- Abra uma consulta nova, cole TODO o arquivo, Ctrl+A dentro do editor e Run.
-- Requer a instalação da SR feita anteriormente. Não apaga registros nem versões.

do $sr_requisitos$
begin
  if to_regclass('public.sr_planilha_registros') is null or to_regclass('public.sr_planilha_versoes') is null then
    raise exception 'Instale primeiro a SR usando sql/INSTALAR_SR_VERSIONADA.sql.';
  end if;
  if to_regclass('public.chamados_oracle') is null or to_regclass('public.perfis_usuarios') is null then
    raise exception 'Projeto incorreto: tabelas do portal não encontradas.';
  end if;
end;
$sr_requisitos$;

alter table public.sr_planilha_registros add column if not exists atualizado_nome text;
alter table public.sr_planilha_registros add column if not exists atualizado_email text;
alter table public.sr_planilha_versoes add column if not exists usuario_nome text;

create or replace function sr_planilha_interno.pode_editar()
returns boolean language sql stable security invoker set search_path = ''
as $$
  select exists (
    select 1 from public.perfis_usuarios p
    where p.id = (select auth.uid()) and p.ativo is true and p.perfil in ('administrador', 'gestor')
      and sr_planilha_interno.pode_consultar()
      and (coalesce(p.mfa_obrigatorio, false) is false or (select auth.jwt() ->> 'aal') = 'aal2')
  );
$$;

create or replace function sr_planilha_interno.validar_registro()
returns trigger language plpgsql security invoker set search_path = ''
as $$
declare
  i integer;
begin
  if jsonb_typeof(new.valores) <> 'array' or jsonb_array_length(new.valores) <> 25 then
    raise exception 'O registro deve conter os 25 campos da SR.';
  end if;
  for i in 0..24 loop
    if jsonb_typeof(new.valores -> i) not in ('string', 'number', 'boolean', 'null') then
      raise exception 'Campo % com tipo inválido.', i;
    end if;
  end loop;
  if btrim(new.valores ->> 2) is distinct from new.numero_sr then
    raise exception 'O número da SR não pode ser alterado.';
  end if;
  if tg_op = 'UPDATE' then
    if auth.uid() is null or not sr_planilha_interno.pode_editar() then
      raise exception using errcode = '42501', message = 'Somente Administrador e Gestor ativos podem editar e salvar a SR.';
    end if;
    if new.id is distinct from old.id or new.origem_revisao is distinct from old.origem_revisao
      or new.linha_origem is distinct from old.linha_origem or new.numero_sr is distinct from old.numero_sr
      or new.aging_calculado is distinct from old.aging_calculado or new.criado_em is distinct from old.criado_em
      or new.valores -> 2 is distinct from old.valores -> 2 then
      raise exception 'A identificação e a origem da SR permanecem fixas.';
    end if;
    if old.aging_calculado and new.valores -> 9 is distinct from old.valores -> 9 then
      raise exception 'Aging é calculado e não pode ser editado nesta linha.';
    end if;
    if new.valores = old.valores then return null; end if;
    new.versao := old.versao + 1;
  else
    new.versao := 1;
  end if;
  new.atualizado_em := clock_timestamp();
  new.atualizado_por := auth.uid();
  if auth.uid() is not null then
    select p.nome, p.email into new.atualizado_nome, new.atualizado_email
    from public.perfis_usuarios p where p.id = auth.uid() and p.ativo is true;
  else
    new.atualizado_nome := null; new.atualizado_email := null;
  end if;
  return new;
end;
$$;

create or replace function public.salvar_sr_planilha(
  p_registro_id uuid, p_versao_atual integer, p_alteracoes jsonb
)
returns public.sr_planilha_registros
language plpgsql security invoker set search_path = ''
as $$
declare
  registro public.sr_planilha_registros;
  novos_valores jsonb;
  item record;
  coluna integer;
begin
  if auth.uid() is null or not sr_planilha_interno.pode_editar() then
    raise exception using errcode = '42501', message = 'Somente Administrador e Gestor ativos podem editar e salvar a SR.';
  end if;
  if p_alteracoes is null or jsonb_typeof(p_alteracoes) <> 'object' or p_alteracoes = '{}'::jsonb then
    raise exception 'Informe os campos alterados.';
  end if;
  select * into registro from public.sr_planilha_registros where id = p_registro_id for update;
  if not found then raise exception 'Registro não encontrado ou sem permissão de acesso.'; end if;
  if p_versao_atual is null or registro.versao <> p_versao_atual then
    raise exception using errcode = 'P0001', message = 'Conflito de versão. Outra pessoa alterou esta linha. Recarregue e revise seus rascunhos antes de salvar.';
  end if;
  novos_valores := registro.valores;
  for item in select * from jsonb_each(p_alteracoes) loop
    if item.key !~ '^(0|[1-9]|1[0-9]|2[0-4])$' then raise exception 'Coluna inválida.'; end if;
    coluna := item.key::integer;
    if coluna = 2 or (coluna = 9 and registro.aging_calculado) then raise exception 'Campo fixo ou calculado.'; end if;
    if jsonb_typeof(item.value) not in ('string', 'number', 'boolean', 'null') then raise exception 'Tipo de valor inválido.'; end if;
    novos_valores := jsonb_set(novos_valores, array[item.key], item.value, false);
  end loop;
  if novos_valores = registro.valores then return registro; end if;
  update public.sr_planilha_registros set valores = novos_valores where id = p_registro_id returning * into registro;
  return registro;
end;
$$;

create or replace function sr_planilha_interno.registrar_versao()
returns trigger language plpgsql security definer set search_path = ''
as $sr_auditoria$
declare
  diferencas jsonb := '[]'::jsonb;
  anterior_em timestamptz;
  i integer;
begin
  if tg_op = 'UPDATE' and (auth.uid() is null or new.atualizado_por is distinct from auth.uid()) then
    raise exception using errcode = '42501', message = 'Autor da alteração inválido.';
  end if;
  if auth.uid() is not null and not exists(select 1 from public.perfis_usuarios p where p.id = auth.uid() and p.ativo is true) then
    raise exception using errcode = '42501', message = 'Perfil ativo não encontrado.';
  end if;
  if tg_op = 'UPDATE' then
    for i in 0..24 loop
      if new.valores -> i is distinct from old.valores -> i then
        select v.alterado_em into anterior_em from public.sr_planilha_versoes v
        where v.registro_id = new.id and (v.versao = 1 or v.alteracoes @> jsonb_build_array(jsonb_build_object('coluna', i)))
        order by v.versao desc limit 1;
        diferencas := diferencas || jsonb_build_array(jsonb_build_object(
          'coluna', i, 'anterior', old.valores -> i, 'novo', new.valores -> i,
          'anterior_em', anterior_em, 'novo_em', new.atualizado_em,
          'usuario_nome', new.atualizado_nome, 'usuario_email', new.atualizado_email));
      end if;
    end loop;
  end if;
  insert into public.sr_planilha_versoes(registro_id, versao, valores, alteracoes, acao, usuario_id, usuario_nome, usuario_email, alterado_em)
  values(new.id, new.versao, new.valores, diferencas,
    case when tg_op = 'INSERT' then 'carga_inicial' else 'edicao' end,
    auth.uid(), new.atualizado_nome, new.atualizado_email, new.atualizado_em);
  return new;
end;
$sr_auditoria$;

-- Complementa somente metadados conhecidos das versões antigas.
-- A data de Antes é a última versão que gravou aquele campo, não a última edição de outro campo.
update public.sr_planilha_versoes v
set alteracoes = (
  select jsonb_agg(e.valor || jsonb_build_object(
    'anterior_em', (select h.alterado_em from public.sr_planilha_versoes h
      where h.registro_id = v.registro_id and h.versao < v.versao
        and (h.versao = 1 or h.alteracoes @> jsonb_build_array(jsonb_build_object('coluna', (e.valor ->> 'coluna')::int)))
      order by h.versao desc limit 1),
    'novo_em', v.alterado_em, 'usuario_nome', v.usuario_nome, 'usuario_email', v.usuario_email) order by e.ordem)
  from jsonb_array_elements(v.alteracoes) with ordinality e(valor, ordem)
)
where jsonb_array_length(v.alteracoes) > 0
  and exists(select 1 from jsonb_array_elements(v.alteracoes) e where not e ? 'novo_em');

-- Recupera a autoria já registrada na versão atual, sem gerar uma edição de dados.
-- A suspensão destes dois gatilhos próprios é protegida pela transação da atualização.
alter table public.sr_planilha_registros disable trigger sr_planilha_validar;
alter table public.sr_planilha_registros disable trigger sr_planilha_versionar;
update public.sr_planilha_registros c
set atualizado_nome = coalesce(c.atualizado_nome, v.usuario_nome),
    atualizado_email = coalesce(c.atualizado_email, v.usuario_email)
from public.sr_planilha_versoes v
where v.registro_id = c.id and v.versao = c.versao
  and ((c.atualizado_nome is null and v.usuario_nome is not null) or (c.atualizado_email is null and v.usuario_email is not null));
alter table public.sr_planilha_registros enable trigger sr_planilha_validar;
alter table public.sr_planilha_registros enable trigger sr_planilha_versionar;

-- Nome histórico não é inventado para versões antigas: o e-mail já registrado é preservado.
revoke all on public.sr_planilha_registros, public.sr_planilha_versoes from public, anon, authenticated;
grant select on public.sr_planilha_registros, public.sr_planilha_versoes to authenticated;
grant update(valores) on public.sr_planilha_registros to authenticated;
drop policy if exists sr_planilha_edicao_restrita on public.sr_planilha_registros;
create policy sr_planilha_edicao_restrita on public.sr_planilha_registros as restrictive for update to authenticated
using ((select sr_planilha_interno.pode_editar())) with check ((select sr_planilha_interno.pode_editar()));

-- Auditoria da aba Planilha (lista compartilhada de chamados).
alter table public.chamados_oracle add column if not exists portal_versao integer not null default 1;
alter table public.chamados_oracle add column if not exists portal_atualizado_em timestamptz not null default now();
alter table public.chamados_oracle add column if not exists portal_atualizado_por uuid;
alter table public.chamados_oracle add column if not exists portal_atualizado_nome text;
alter table public.chamados_oracle add column if not exists portal_atualizado_email text;

create table if not exists public.chamados_oracle_versoes (
  id uuid primary key default gen_random_uuid(),
  ano integer not null,
  numero_sr text not null,
  versao integer not null check(versao > 0),
  depois jsonb not null check(jsonb_typeof(depois) = 'object'),
  alteracoes jsonb not null default '[]'::jsonb check(jsonb_typeof(alteracoes) = 'array'),
  acao text not null check(acao in ('carga_inicial','edicao')),
  usuario_id uuid references auth.users(id) on delete set null,
  usuario_nome text,
  usuario_email text,
  alterado_em timestamptz not null,
  unique(ano, numero_sr, versao)
);
create index if not exists chamados_oracle_versoes_usuario_idx on public.chamados_oracle_versoes(usuario_id);
alter table public.chamados_oracle_versoes enable row level security;
alter table public.chamados_oracle enable row level security;

create or replace function sr_planilha_interno.pode_consultar_chamado(p_ano integer)
returns boolean language sql stable security invoker set search_path = '' as $ch_consulta$
  select exists(select 1 from public.perfis_usuarios p where p.id = (select auth.uid()) and p.ativo is true
    and (p.perfil = 'administrador' or p.permissoes ->> ('chamados_' || p_ano::text) = 'true' or p.permissoes ->> 'inicio' = 'true')
    and (coalesce(p.mfa_obrigatorio, false) is false or (select auth.jwt() ->> 'aal') = 'aal2'));
$ch_consulta$;

create or replace function sr_planilha_interno.pode_editar_chamado(p_ano integer)
returns boolean language sql stable security invoker set search_path = '' as $ch_edicao$
  select exists(select 1 from public.perfis_usuarios p where p.id = (select auth.uid()) and p.ativo is true
    and (p.perfil = 'administrador' or (p.perfil = 'gestor' and p.permissoes ->> ('chamados_' || p_ano::text) = 'true'))
    and (coalesce(p.mfa_obrigatorio, false) is false or (select auth.jwt() ->> 'aal') = 'aal2'));
$ch_edicao$;

drop policy if exists chamados_portal_editores on public.chamados_oracle;
create policy chamados_portal_editores on public.chamados_oracle for update to authenticated
using (sr_planilha_interno.pode_editar_chamado(ano)) with check (sr_planilha_interno.pode_editar_chamado(ano));
drop policy if exists chamados_portal_edicao_restrita on public.chamados_oracle;
create policy chamados_portal_edicao_restrita on public.chamados_oracle as restrictive for update to authenticated
using (sr_planilha_interno.pode_editar_chamado(ano)) with check (sr_planilha_interno.pode_editar_chamado(ano));
drop policy if exists chamados_portal_insercao_restrita on public.chamados_oracle;
create policy chamados_portal_insercao_restrita on public.chamados_oracle as restrictive for insert to authenticated
with check (sr_planilha_interno.pode_editar_chamado(ano));
drop policy if exists chamados_portal_exclusao_restrita on public.chamados_oracle;
create policy chamados_portal_exclusao_restrita on public.chamados_oracle as restrictive for delete to authenticated
using (sr_planilha_interno.pode_editar_chamado(ano));
drop policy if exists chamados_historico_consulta on public.chamados_oracle_versoes;
create policy chamados_historico_consulta on public.chamados_oracle_versoes for select to authenticated
using (sr_planilha_interno.pode_consultar_chamado(ano));

-- Permissões de consulta existentes na lista continuam válidas. Apenas a escrita é limitada.
revoke update on public.chamados_oracle from public, anon, authenticated;
do $ch_privilegios$
declare col record;
begin
  for col in select a.attname from pg_catalog.pg_attribute a where a.attrelid = 'public.chamados_oracle'::regclass and a.attnum > 0 and not a.attisdropped loop
    execute format('revoke update(%I) on public.chamados_oracle from public, anon, authenticated', col.attname);
  end loop;
end;
$ch_privilegios$;
grant update(resumo,issue_type,servico,status,severidade,criado_texto,atualizado_texto,fechado_texto,
  contato_primario,grupo_usuario,tenancy,impacto_negocio,conta,referencia_cliente,url_recurso) on public.chamados_oracle to authenticated;
revoke all on public.chamados_oracle_versoes from public, anon, authenticated;
grant select on public.chamados_oracle_versoes to authenticated;

create or replace function sr_planilha_interno.validar_chamado()
returns trigger language plpgsql security invoker set search_path = '' as $ch_validar$
begin
  if current_user not in ('postgres','service_role','supabase_admin') and not sr_planilha_interno.pode_editar_chamado(new.ano) then
    raise exception using errcode = '42501', message = 'Somente Administrador e Gestor ativos podem editar e salvar a planilha.';
  end if;
  if tg_op = 'UPDATE' and (new.ano is distinct from old.ano or new.numero_sr is distinct from old.numero_sr) then
    raise exception 'A identificação do chamado permanece fixa.';
  end if;
  if tg_op = 'UPDATE' and (to_jsonb(new) - array['portal_versao','portal_atualizado_em','portal_atualizado_por','portal_atualizado_nome','portal_atualizado_email']) =
     (to_jsonb(old) - array['portal_versao','portal_atualizado_em','portal_atualizado_por','portal_atualizado_nome','portal_atualizado_email']) then return null; end if;
  new.portal_versao := case when tg_op = 'UPDATE' then old.portal_versao + 1 else 1 end;
  new.portal_atualizado_em := clock_timestamp();
  new.portal_atualizado_por := auth.uid();
  if auth.uid() is not null then
    select p.nome, p.email into new.portal_atualizado_nome, new.portal_atualizado_email
    from public.perfis_usuarios p where p.id = auth.uid() and p.ativo is true;
  else
    new.portal_atualizado_nome := 'Importação / manutenção do banco'; new.portal_atualizado_email := null;
  end if;
  return new;
end;
$ch_validar$;

create or replace function sr_planilha_interno.registrar_chamado_versao()
returns trigger language plpgsql security definer set search_path = '' as $ch_auditar$
declare diffs jsonb := '[]'::jsonb; campo record; anterior_em timestamptz;
begin
  if tg_op = 'UPDATE' then
    for campo in select * from jsonb_each(to_jsonb(new) - array['portal_versao','portal_atualizado_em','portal_atualizado_por','portal_atualizado_nome','portal_atualizado_email']) loop
      if campo.value is distinct from to_jsonb(old) -> campo.key then
        select v.alterado_em into anterior_em from public.chamados_oracle_versoes v
        where v.ano = new.ano and v.numero_sr = new.numero_sr
          and (v.versao = 1 or v.alteracoes @> jsonb_build_array(jsonb_build_object('campo', campo.key)))
        order by v.versao desc limit 1;
        diffs := diffs || jsonb_build_array(jsonb_build_object('campo', campo.key,
          'anterior', to_jsonb(old) -> campo.key, 'novo', campo.value,
          'anterior_em', anterior_em, 'novo_em', new.portal_atualizado_em,
          'usuario_nome', new.portal_atualizado_nome, 'usuario_email', new.portal_atualizado_email));
      end if;
    end loop;
  end if;
  insert into public.chamados_oracle_versoes(ano,numero_sr,versao,depois,alteracoes,acao,usuario_id,usuario_nome,usuario_email,alterado_em)
  values(new.ano,new.numero_sr,new.portal_versao,to_jsonb(new),diffs,
    case when tg_op = 'INSERT' then 'carga_inicial' else 'edicao' end,
    new.portal_atualizado_por,new.portal_atualizado_nome,new.portal_atualizado_email,new.portal_atualizado_em);
  return new;
end;
$ch_auditar$;

insert into public.chamados_oracle_versoes(ano,numero_sr,versao,depois,acao,usuario_id,usuario_nome,usuario_email,alterado_em)
select ano,numero_sr,portal_versao,to_jsonb(c),'carga_inicial',portal_atualizado_por,portal_atualizado_nome,portal_atualizado_email,portal_atualizado_em
from public.chamados_oracle c on conflict(ano,numero_sr,versao) do nothing;

drop trigger if exists chamados_portal_validar on public.chamados_oracle;
create trigger chamados_portal_validar before insert or update on public.chamados_oracle for each row execute function sr_planilha_interno.validar_chamado();
drop trigger if exists chamados_portal_versionar on public.chamados_oracle;
create trigger chamados_portal_versionar after insert or update on public.chamados_oracle for each row execute function sr_planilha_interno.registrar_chamado_versao();

revoke execute on function sr_planilha_interno.pode_consultar_chamado(integer), sr_planilha_interno.pode_editar_chamado(integer),
 sr_planilha_interno.validar_chamado(), sr_planilha_interno.registrar_chamado_versao(), sr_planilha_interno.validar_registro(), sr_planilha_interno.registrar_versao()
from public, anon, authenticated;
grant usage on schema sr_planilha_interno to authenticated;
grant execute on function sr_planilha_interno.pode_consultar_chamado(integer), sr_planilha_interno.pode_editar_chamado(integer) to authenticated;
notify pgrst, 'reload schema';

select 'v9 instalada: Administrador/Gestor, autoria e auditoria da SR e da Planilha.' as resultado;

-- Carrega as 244 linhas da base inicial (duplicata 216 removida na V19). Execute depois de 01_criar_tabelas_sr_versionadas.sql.
-- Pode ser reexecutado: não substitui linhas existentes nem alterações já salvas.

insert into public.sr_planilha_registros(origem_revisao, linha_origem, numero_sr, valores, aging_calculado)
select 'e2b31231f1248752', item.value ->> 'id', btrim(item.value -> 'values' ->> 2),
  item.value -> 'values', coalesce((item.value ->> 'agingFormula')::boolean, false)
from jsonb_array_elements($sr_carga_20261008$[{"id":"2","values":["leonardo.guilherme@ninecon.com.br","16/12/2025 14:20","4-0001606629 ","n/a","n/a","n/a","n/a","ER:RAPID SETUP FBDI LIMITATION ON BULK CONFIGURATION OF TAX RULE RESULTS (TAX REPORTS AND LEGAL MESSAGE","Tax",null,null,null,null,"Sim",null,null,null,null,null,null,null,null,null,null,null],"agingFormula":false},{"id":"3","values":["leonardo.guilherme@ninecon.com.br","16/12/2025 15:21","4-0001607105 ","n/a","n/a","n/a","n/a","ICMS-ST PREVIOUSLY WITHHELD NOT RETRIEVED FOR OUTBOUND NF-E ISSUANCE","Tax",295.36041666667006,"13/08 - Fechou SR",null,null,"Sim","ALTO",null,"sim","sim","Impacto fiscal\nSetup","Impacta revenda de varejo (ex.: linguiça)\n80% da operação","Problema no cálculo do imposto de operações que possuem ICMS-ST, não tenho o % de impacto","Sim",null,null,null],"agingFormula":true},{"id":"4","values":["jonatan.molossi@ninecon.com.br","16/12/2025 15:34","4-0001607193 ","n/a","n/a","n/a","n/a","I - Too many objects match the primary key oracle.jbo.Key[300000066689474 ].. (DOO-2685874)","Receivables",295.35138888889196,"10/07 - Erro inicial foi resolvido, porém consultor solicitou a relação dos atributos do PVO, pois estão constando novos atributos não mapeados",null,null,"Sim","Médio",null,null,null,"Impacta criação de OM manuais - CRF#05 e CRF#06",null,"Afeta ordem de vendas manuais, ficaria sem retenção de crédito, são poucos cenários",null,null,null,null],"agingFormula":true},{"id":"5","values":["bruno.petroveski@ninecon.com.br","05/01/2026 17:40","4-0001728530 ","n/a","n/a","n/a","n/a","HTTP/1.1 500 Internal Server Error","Transportation Intelligence",275.2638888888905,"23/04 - Suporte questionou se consultor consegue replicar o problema",null,null,"Sim","Baixo",null,null,null,"Solução alternativa com o uso do DBXML",null,null,null,null,null,null],"agingFormula":true},{"id":"6","values":["leonardo.guilherme@ninecon.com.br","12/01/2026 16:33","4-0001780131 ","n/a","n/a","n/a","n/a","FDG GENERATES DUPLICATE TAXABLE BASE FOR TAXES DUE TO PRICE ADJUSTMENT (LIST PRICE VS ADJUSTMENT)","Tax",268.31041666666715,"01/05 - Solução ofertada resolveu, em testes",null,null,"Sim","ALTO",null,null,null,"Testes unitário do faturamento foram parados, transfer order e OM, utilizam price adjustment",null,"Problema no faturamento de orignadas de Ordens de Transferência e pelo OM","Sim",null,null,null],"agingFormula":true},{"id":"7","values":["leonardo.guilherme@ninecon.com.br","28/01/2026 09:52","4-0001903128 ","n/a","n/a","n/a","n/a","TAX – Calculation of Tax Base Reduction with Discount","Inventory Management",252.5888888888876,"19/06 -Solicitei para a Solange atualizar a SR solicitando informação sobre Idea ou forma que será entregue esta melhoria",null,null,"Sim","Alto",null,null,null,null,null,"Documentos fiscais com redução de base possuem este problema (FDC)","Sim",null,null,null],"agingFormula":true},{"id":"8","values":["alisson.gomide@ninecon.com.br","05/02/2026 10:56","4-0001985287 ","n/a","n/a","n/a","n/a","S2S -- No response from the tax estimation service","Purchasing",244.5444444444438,"30/04 - Foi aberta nova SR a pedido do suporte, esta devera ser fechada",null,null,null,"ALTO",null,null,null,"GCO#02",null,null,null,null,null,null],"agingFormula":true},{"id":"9","values":["jair.santos@plumaagro.com.br","11/02/2026 14:06","4-0002038618 ","n/a","n/a","n/a","n/a","DC MOVE : Preciso de uma analise para migração do datacenter phoenix USA para VCP-VINHEDO - BRA","Global Human Resources",238.41249999999854,"07/06 - Favor fechar a SR, seguiremos com o time de CHO para a conclusão da mudança de datacenter",null,null,null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"10","values":["leonardo.guilherme@ninecon.com.br","16/02/2026 17:13","4-0002077640 ","n/a","n/a","n/a","n/a","INCORRECT ICMS TAX AMOUNT CONSIDERED IN PIS/COFINS TAXABLE BASE REDUCTION","Tax",233.28263888888614,"17/06 - SR resolvida através do CWB",null,null,"Sim","ALTO",null,null,null,"Erro na saída (faturamento)\nSetup",null,"Impacto em todas os cenários de faturamento com redução na base de cálculo do imposto","Sim",null,null,null],"agingFormula":true},{"id":"11","values":["roberto.velasco@ninecon.com.br","17/02/2026 08:19","4-0002082570 ","n/a","n/a","n/a","n/a","Foi criado uma nova categoria de gerente do projeto","Project Foundation",232.65347222222044,"05/08 - Foi solicitado a troca do analista, solicitaremos ajuda da Janeth",null,null,"sim","Baixo",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"12","values":["vanessa.breseghello@ninecon.com.br","10/03/2026 17:42","4-0002263237 ","n/a","n/a","n/a","n/a","BUG.DOC:39070910:LOGLS – Clarification Needed on Shipment Lifecycle and Agent Execution Flow","LOGLS",211.2624999999971,"08/05 - Solução oferecida, em análise com consultor",null,null,null,"Baixo",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"13","values":["vanessa.breseghello@ninecon.com.br","10/03/2026 18:07","4-0002263390 ","n/a","n/a","n/a","n/a","Unexpected Invoice Generation in OTM with LOGLS Reconciliation Status \"Alert\"","LOGLS",211.2451388888876,"27/04 - Patch de correcao disponibilizado, em teste",null,null,null,"ALTO",null,null,null,null,null,"Processo parado, solicitar agenda para Cheachire","Sim",null,null,null],"agingFormula":true},{"id":"14","values":["jonatan.molossi@ninecon.com.br","12/03/2026 08:39","4-0002280062 ","n/a","n/a","n/a","n/a","Flexfield filled in sales order line redwood didn't show the filled value.","Order Management",209.63958333332994,"10/08 - Solução funcionou",null,null,"sim","Médio",null,null,null,"Redwood",null,"Uso da tela Redwood - Flex field não fica visível para o usuário","Sim",null,null,null],"agingFormula":true},{"id":"15","values":["leonardo.guilherme@ninecon.com.br","17/03/2026 14:10","4-0002319595 ","n/a","n/a","n/a","n/a","Taxable Basis formula with Price Thresholds is not working with Product Fiscal Classification Type (LACLS)","Tax",204.409722222219,"22/06 - Problema resolvido após OWC",null,null,"Sim","ALTO",null,null,null,"Setup",null,"Impacto em todos os cenários de Mato Grosso do Sul","Sim",null,null,null],"agingFormula":true},{"id":"16","values":["vanessa.breseghello@ninecon.com.br","17/03/2026 15:17","4-0002320145 ","n/a","n/a","n/a","n/a","Support for External Vale Pedágio (REPOM) Integration for MDF-e / CIOT Emission","LOGLS",204.36319444444234,"17/07 - ETA 16/Out/26",null,null,null,"ALTO",null,null,null,"Setup",null,null,null,null,null,null],"agingFormula":true},{"id":"17","values":["vanessa.breseghello@ninecon.com.br","24/03/2026 18:22","4-0002374557 ","n/a","n/a","n/a","n/a","LOGLSBR – MDF-e not generated after correct Shipment / Release / NFe integration","LOGLS",197.23472222222335,"20/04 - Consultora retornou que MDFe foi gerado, precisou incluir uma outra role no usuario",null,null,null,"ALTO",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"18","values":["wendel.andrade@ninecon.com.br","27/03/2026 17:28","4-0002403571 ","n/a","n/a","n/a","n/a","Refund - You must enter a CNPJ or CPF taxpayer identifier for the payee AR-856622","Receivables",194.2722222222219,"13/07 - Favor solicitar o backport para 26C na SR",null,null,"sim","Médio",null,null,null,"Não existe no Planner",null,"Processo core que não está funcionando, volume pequeno",null,null,null,null],"agingFormula":true},{"id":"19","values":["jair.santos@plumaagro.com.br","30/03/2026 08:03","4-0002415107 ","n/a","n/a","n/a","n/a","*OTM DC MOVE : Preciso de uma analise para migração do datacenter phoenix USA para VCP-VINHEDO - BRA","OTM",191.6645833333314,"07/06 - Favor fechar a SR, seguiremos com o time de CHO para a conclusão da mudança de datacenter",null,null,null,"Médio",null,null,null,"Não existe no Planner",null,null,null,null,null,null],"agingFormula":true},{"id":"20","values":["jair.santos@plumaagro.com.br","30/03/2026 13:24","4-0002418263 ","n/a","n/a","n/a","n/a","* ERP DC MOVE : Preciso de uma analise para migração do datacenter Alschburn USA para VCP-VINHEDO-BR","Global Human Resources",191.4416666666657,"07/06 - Favor fechar a SR, seguiremos com o time de CHO para a conclusão da mudança de datacenter",null,null,null,"Médio",null,null,null,"Não existe no Planner",null,null,null,null,null,null],"agingFormula":true},{"id":"21","values":["leandro.cavalheiro@ninecon.com.br","01/04/2026 23:17","4-0002442194 ","n/a","n/a","n/a","n/a","ITAU - BOLETO | LACLS_BR_EFT_ITA | ERROR LAYOUT","LACLS",189.02986111111386,"30/04 - Patch em testes, aguardando retorno do banco",null,null,null,"ALTO",null,null,null,null,null,"Erro no layout do arquivo de pagamento via Boleto para o Itaú","Sim",null,null,null],"agingFormula":true},{"id":"22","values":["leandro.cavalheiro@ninecon.com.br","02/04/2026 14:36","4-0002449542 ","n/a","n/a","n/a","n/a","*BRADESCO PIX | LACLS_BR_AP_BRA_240_PIX | ERROR LAYOUT","LACLS",188.39166666667006,"05/05 - Solução oferecida, em análise com o banco, prev.: 19/Mai",null,null,null,"ALTO",null,null,null,null,null,"Erro no layout do arquivo de pagamento via Pix para o Bradesco","Sim",null,null,null],"agingFormula":true},{"id":"23","values":["antonio.sobrinho@ninecon.com.br","02/04/2026 15:34","4-0002449951 ","n/a","n/a","n/a","n/a","TAX - Enable/Disable Rules in Manage Tax Rules","Tax",188.35138888889196,"24/04 - Consultor informou que erro não voltou a ocorrer, estão monitorando",null,null,null,"ALTO",null,null,null,null,null,"Regras estão sendo desativadas, gerando erro no momento da geração ou recebimento da NF","Sim",null,null,null],"agingFormula":true},{"id":"24","values":["leandro.cavalheiro@ninecon.com.br","02/04/2026 18:55","4-0002451010 ","n/a","n/a","n/a","n/a","*SAFRA PIX | LACLS_BR_AP_SAF_240_PIX | ERROR LAYOUT","LACLS",188.21180555555475,"30/04 - Patch em testes, aguardando retorno do banco",null,null,null,"ALTO",null,null,null,null,null,"Erro no layout do arquivo de pagamento via Pix para o Safra","Sim",null,null,null],"agingFormula":true},{"id":"25","values":["leandro.cavalheiro@ninecon.com.br","02/04/2026 22:34","4-0002451686 ","n/a","n/a","n/a","n/a","*CAIXA EFT | LACLS_BR_EFT_CEF.rtf | ERROR LAYOUT","LACLS",188.05972222222044,"30/04 - Layout ajustado, aguardando retorno do banco",null,null,null,"ALTO",null,null,null,null,null,"Erro no layout do arquivo de pagamento via Transferência para a CEF","Sim",null,null,null],"agingFormula":true},{"id":"26","values":["vanessa.chiochetta@ninecon.com.br","06/04/2026 16:16","4-0002471769 ","n/a","n/a","n/a","n/a","#26A-A-Redwood Process Requisitions - Update from Catalog blocked for budgetary control requisition lines;","Purchasing",184.3222222222248,"07/06 - Favor fechar a SR, faremos o acompanhamento deste issue com o time de produto",null,null,"verificar tradução","ALTO",null,null,null,null,null,"Trava o uso da tela Redwood, pois precisam trocar o item",null,null,null,null],"agingFormula":true},{"id":"27","values":["vanessa.breseghello@ninecon.com.br","08/04/2026 13:54","4-0002491891 ","n/a","n/a","n/a","n/a","Document Generator: Download Button Not Triggering Any Action","LOGLS",182.42083333332994,"08/05 - Patch de correção liberado para testes",null,null,null,"ALTO",null,null,null,null,null,"Problema na baixa do relatório","Sim",null,null,null],"agingFormula":true},{"id":"28","values":["leonardo.guilherme@ninecon.com.br","10/04/2026 10:20","4-0002510089 ","n/a","n/a","n/a","n/a","FDC – FAILURE IN FISCAL FLOW AND ADDRESS DERIVATION FOR ISSUED BY BUYER CFOPS IN INTERFACE EXCEPTION","Inventory Management",180.56944444444525,"13/05 - Durante a OWC resolveu um CFOP, serão testados os demais",null,null,"Sim","ALTO",null,null,null,"NF de produtor rural, está parando na interface",null,"Processo manual é inviável devido a volumetria de recebimentos das Invoices de Produtor Rural","Sim",null,null,null],"agingFormula":true},{"id":"29","values":["mateus.fetzner@plumaagro.com.br","13/04/2026 11:26","4-0002527355 ","n/a","n/a","n/a","n/a","#26A-A Approval rule is not activating","Self Service Procurement",177.52361111110804,"27/04 - Solucao oferecida, em testes",null,null,null,"Médio",null,null,null,"Não existe no Planner",null,"Impacto nas regras de aprovações",null,null,null,null],"agingFormula":true},{"id":"30","values":["jair.santos@plumaagro.com.br","15/04/2026 12:21","4-0002549876 ","n/a","n/a","n/a","n/a","Verify if there is technical feasibility for data center migration - Phoenix to VCP-Vinhedo - BRA","FCCS",175.48541666667006,"07/06 - Favor fechar a SR, seguiremos com o time de CHO para a conclusão da mudança de datacenter",null,null,null,"Baixo",null,null,null,"Não existe no Planner",null,null,null,null,null,null],"agingFormula":true},{"id":"31","values":["alisson.gomide@ninecon.com.br","16/04/2026 10:11","4-0002558859 ","n/a","n/a","n/a","n/a","#26A-A-Customize the Redwood Approvals Work Area","Purchasing",174.5756944444438,"07/05 - Suporte informou que não há suporte para customização",null,null,null,"ALTO",null,null,null,"GCO#20",null,"Problema na customização da tela redwood de aprovação, não pode criar campos na tela Classic",null,null,null,null],"agingFormula":true},{"id":"32","values":["leandro.cavalheiro@ninecon.com.br","18/04/2026 21:39","4-0002576414 ","n/a","n/a","n/a","n/a","DAYCOVAL | LACLS_BR_EFT_DAY | BOLETO | ERROR LAYOUT","LACLS",172.0979166666657,"05/08 - Remessa validada, em teste com o cliente",null,null,null,"ALTO",null,"durante",null,"Daycoval","Belo e Pluma",null,"Sim",null,null,null],"agingFormula":true},{"id":"33","values":["douglas.sampaio@ninecon.com.br","24/04/2026 09:00","4-0002625123 ","n/a","n/a","n/a","n/a","order movement not populating source location and dest location as expected","OTM",166.625,"27/05 - Foi compartilhado a forma que o produto funciona, em análise com consultor",null,null,null,"Baixo",null,null,null,null,null,"Problema na Order Movement",null,null,null,null],"agingFormula":true},{"id":"34","values":["vanessa.breseghello@ninecon.com.br","24/04/2026 10:15","4-0002625734 ","n/a","n/a","n/a","n/a","BUG:39260148:Integration Failure in OIC due to HARDCODED OTM Endpoint in Patch 38838705","LOGLS",166.57291666666424,"28/04 -Bug: 39260148, solucao aplicada no ambiente Pluma (Patch oficial 06/05)",null,null,null,"ALTO",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"35","values":["bruno.petroveski@ninecon.com.br","24/04/2026 10:18","4-0002625762 ","n/a","n/a","n/a","n/a","SCSD - Fusion Applications TLS Issue","Financials Common Module",166.5708333333314,"19/05 - Consultor solicitou a confirmação por parte do suporte sobre possível impacto para a Pluma",null,null,null,"Não Existe",null,null,null,"Não existe no Planner",null,"Atualizado certificado no dia 24/Maio",null,null,null,null],"agingFormula":true},{"id":"36","values":["leonardo.guilherme@ninecon.com.br","27/04/2026 15:11","4-0002643373","n/a","n/a","n/a","n/a","CCC (ER): FDC – INCLUDE CFOP IN THE STANDARD AND STANDARD ISSUED BY BUYER FLOWS","Inventory Management",163.36736111110804,"30/04 - Criado Idea 957388 - Porem precisamos que esta solucao seja entregue dentro do projeto, escalar com Warley\n08/09 (TBD)",null,null,null,"ALTO",null,"sim",null,null,"impacta processo de manufatura","impacta processo de industrialização de terceiros, CFOP de OSP",null,null,null,null],"agingFormula":true},{"id":"37","values":["alisson.gomide@ninecon.com.br","28/04/2026 15:06","4-0002653951","n/a","n/a","n/a","n/a","You must provide a valid value for the Product Fiscal Classification attribute.","Purchasing",162.3708333333343,"19/05 - Consultor informou que a solução está em teste, qual previsão de conclusão dos testes?",null,null,null,"ALTO",null,null,null,"GCO#02",null,null,null,null,null,null],"agingFormula":true},{"id":"38","values":["larissa.amandio@ninecon.com.br","28/04/2026 15:09","4-0002653980","n/a","n/a","n/a","n/a","Parts List not shown in Redwood during Work Definition edit; visible in Classic screen.","Maintenance",162.36875000000146,"03/06 - Suporte informou que está previsto para ser entregue final de 2027",null,null,"sim","ALTO",null,null,null,"Redwood",null,"Funciona no Classic, não funciona no Redwood",null,null,null,null],"agingFormula":true},{"id":"39","values":["larissa.amandio@ninecon.com.br","28/04/2026 15:18","4-0002654057","n/a","n/a","n/a","n/a","Maintenance Program blank in Redwood; loads normally in Classic (Forms).","Maintenance",162.3625000000029,"22/07 - Configuração ajustada, problema resolvido, será fechada",null,null,null,"ALTO",null,null,null,"Redwood",null,"Funciona no Classic, não funciona no Redwood somente em DEV2",null,null,null,null],"agingFormula":true},{"id":"40","values":["wendel.andrade@ninecon.com.br","28/04/2026 18:04","4-0002655021","n/a","n/a","n/a","n/a","Can not choose option \"Fiscal Line Details Attributes Supplement for Brazil Goods Export\"","Financials for the Americas",162.24722222222044,"18/05 - Suporte compartilhou um plano de ação",null,null,"sim","ALTO",null,null,null,null,null,"Não consegue fazer a escrituração da NF (Ex.: NF de exportação)",null,null,null,null],"agingFormula":true},{"id":"41","values":["vanessa.breseghello@ninecon.com.br","30/04/2026 14:20","4-0002673367","n/a","n/a","n/a","n/a","LOGLS Loader Files Stuck in \"NEW\" Status – Layout Not Identified and Processing Not Triggered","LOGLS",160.402777777781,"30/04 - Agendada OWC para 04/Mai",null,null,null,"ALTO",null,null,null,null,null,"Impacto na captura do MDFe pela Adejo",null,null,null,null],"agingFormula":true},{"id":"42","values":["leonardo.guilherme@ninecon.com.br","01/05/2026 03:05","4-0002676929","n/a","n/a","n/a","n/a","The Fiscal Document status does not change to Captured - FDC Redwood","Inventory Management",159.871527777781,"13/05 -Novo plano de ação foi compartilhado",null,null,null,"Médio",null,null,null,null,null,"Tela Classic funciona",null,null,null,null],"agingFormula":true},{"id":"43","values":["leonardo.guilherme@ninecon.com.br","04/05/2026 11:13","4-0002693386 ","n/a","n/a","n/a","n/a","FDC - REDWOOD INTERFACE EXCEPTIONS SCREEN IS NOT LOADING ITEM LINES","Inventory Management",156.53263888888614,"26/05 - Suporte informou que esta funcionalidade entrará somente na 26C (Ago/26)",null,null,null,"ALTO",null,null,null,"Redwood",null,"Tela Classic funciona",null,null,null,null],"agingFormula":true},{"id":"44","values":["leonardo.guilherme@ninecon.com.br","05/05/2026 09:32","4-0002702573 ","n/a","n/a","n/a","n/a","FDC – REDWOOD - THE [CANCEL] AND [SAVE AND CLOSE] BUTTONS ON THE FISCAL ATTRIBUTE SCREEN ARE NOT WOR","Inventory Management",155.6027777777781,"01/07 - 26D - backport para 26C",null,null,null,"Médio",null,null,null,"Redwood",null,"Tela Classic funciona",null,null,null,null],"agingFormula":true},{"id":"45","values":["larissa.amandio@ninecon.com.br","05/05/2026 14:35","4-0002705614 ","n/a","n/a","n/a","n/a","No back option in UI; must restart flow from beginning (Work Areas Redwood UI)","Manufacturing",155.3923611111095,"21/05 - Ocorreu OWC? Não há registro na SR",null,null,null,"ALTO",null,null,null,null,null,"Funciona no Classic, não funciona no Redwood",null,null,null,null],"agingFormula":true},{"id":"46","values":["vanessa.breseghello@ninecon.com.br","06/05/2026 13:57","4-0002716543 ","n/a","n/a","n/a","n/a","LOGLS MDF-e Canonical File – Driver CPF and Equipment Information Returned Empty in Fleet Scenario","LOGLS",154.4187499999971,"16/0",null,null,null,"ALTO",null,null,null,"Setup",null,null,"Sim",null,null,null],"agingFormula":true},{"id":"47","values":["leonardo.guilherme@ninecon.com.br","10/05/2026 12:45","4-0002746255 ","n/a","n/a","n/a","n/a","THE USER IS UNABLE TO VIEW THE CHARGE ALLOCATION IN FDC AFTER THE CHANGE FROM 26A TO 26B","Inventory Management",150.46875,"01/06 - Consultor informou a disponibilidade para fazer OWC - 02/Jun",null,null,null,"Baixo",null,null,null,null,null,"Tela Classic funciona",null,null,null,null],"agingFormula":true},{"id":"48","values":["leandro.cavalheiro@ninecon.com.br","11/05/2026 06:08","4-0002750467 ","n/a","n/a","n/a","n/a","PROACTIVE MONITORING: Intercompany Setup Missing causing LIAB ACCT INVALID hold - Incident ID 123921","Payables",149.7444444444409,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"49","values":["wendel.andrade@ninecon.com.br","11/05/2026 09:11","4-0002752342 ","n/a","n/a","n/a","n/a","PROACTIVE MONITORING: Leading or trailing spaces in Account Name or Account Number","Receivables",149.61736111110804,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"50","values":["wendel.andrade@ninecon.com.br","11/05/2026 09:12","4-0002752346 ","n/a","n/a","n/a","n/a","PROACTIVE MONITORING: Leading or trailing spaces in Party Name","Receivables",149.6166666666686,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"51","values":["larissa.amandio@ninecon.com.br","12/05/2026 16:13","4-0002767455 ","n/a","n/a","n/a","n/a","Inconsistency in the Number of Work Orders Displayed on My Maintenance Work Screen After Refresh","Maintenance",148.32430555555766,"07/07 - Patch será entregue junto com o patch de segurança que será aplicado em 13/Jul",null,null,null,"Baixo",null,null,null,null,null,"Na tela Redwood o filtro não está funcionando",null,null,null,null],"agingFormula":true},{"id":"52","values":["vanessa.breseghello@ninecon.com.br","13/05/2026 11:49","4-0002776025 ","n/a","n/a","n/a","n/a","Document Generator Screen Missing Drill-Down Navigation Links","LOGLS",147.50763888889196,"14/05 – Aberto Bug 39374442 para análise de DEV",null,null,null,"ALTO",null,null,null,null,null,null,"Sim",null,null,null],"agingFormula":true},{"id":"53","values":["vanessa.chiochetta@ninecon.com.br","14/05/2026 11:53","4-0002786021 ","n/a","n/a","n/a","n/a","#26B-A-NR-Redwood Sourcing Error When Creating Surrogate Response and Viewing Supplier Response","Sourcing",146.5048611111124,"20/05 - Consultora informou que resolveu sozinha",null,null,null,"Não existe",null,null,null,"Não existe no Planner",null,null,null,null,null,null],"agingFormula":true},{"id":"54","values":["leonardo.guilherme@ninecon.com.br","14/05/2026 17:28","4-0002788393 ","n/a","n/a","n/a","n/a","FDC - Error loading CFOP 1604 for ICMS credit - Interface Exceptions","Inventory Management",146.2722222222219,"14/07 - Suporte solicitou mais informações, aguardando consultor",null,null,"Sim","Médio",null,null,null,null,null,"Idea: 874811",null,null,null,null],"agingFormula":true},{"id":"55","values":["wendel.andrade@ninecon.com.br","18/05/2026 10:51","4-0002811202 ","n/a","n/a","n/a","n/a","PROACTIVE MONITORING: Leading or trailing spaces in Party Name","Receivables",142.54791666667006,"18/05 - SR proativa, problema de espaços no Party Name do cliente",null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"56","values":["wendel.andrade@ninecon.com.br","18/05/2026 10:56","4-0002811256 ","n/a","n/a","n/a","n/a","PROACTIVE MONITORING: Leading or trailing spaces in Account Name or Account Number will impact use of customers in receipt application or running reports.","Receivables",142.5444444444438,"18/05 - SR Proativa, problema de espaços no Account name e Account Number do cliente",null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"57","values":["leonardo.guilherme@ninecon.com.br","18/05/2026 11:32","4-0002811643 ","07/10/2026 11:52","Customer Working","2-Significant","Never escalated","TAX RULE WITH PARTY FISCAL CLASSIFICATION DETERMINING FACTOR CLASS IS NOT WORKING","Order Management",142.51944444444234,"07/10 - Plano de ação, em análise com o consultor Ninecon",null,null,null,"ALTO",null,null,null,null,"mudar a regra do setup de tax",null,null,null,null,null],"agingFormula":true},{"id":"58","values":["bruno.petroveski@ninecon.com.br","19/05/2026 06:39","4-0002819482 ","n/a","n/a","n/a","n/a","System Options page loading indefinitely in MFM","LACLS",141.7229166666657,"05/06 - Foi disponibilizado um patch, aguardando retorno do consultor",null,null,null,"ALTO",null,null,null,"GES#09 e GES#10",null,"Aplicou solução de contorno, patch oficial dia 12/06",null,null,null,null],"agingFormula":true},{"id":"59","values":["diogenes.ravaglia@ninecon.com.br","19/05/2026 15:29","4-0002824623 ","n/a","n/a","n/a","n/a","IDCS/IAM connection intermittency in Cloud Infrastructure","IDCS",141.35486111111095,"21/05 - Consultor reforçou pedido de análise sobre o erro que persiste",null,null,null,"Não Existe",null,null,null,null,null,"Tratando nas duas SR: 4-0002838540  e 4-0002868816 ",null,null,null,null],"agingFormula":true},{"id":"60","values":["bruno.petroveski@ninecon.com.br","19/05/2026 17:09","4-0002825381 ","n/a","n/a","n/a","n/a","More details about this change: Starting June 8, is updating how OAuth credentials are man..","IDCS",141.2854166666657,"21/05 - Suporte informou que o cliente não será afetado com esta atualização",null,null,null,"Não Existe",null,null,null,"Não existe no Planner",null,null,null,null,null,null],"agingFormula":true},{"id":"61","values":["vanessa.chiochetta@ninecon.com.br","20/05/2026 14:04","4-0002834695 ","n/a","n/a","n/a","n/a","Currency conversion isn't defined","Self Service Procurement",140.41388888889196,"29/07 - Suporte informou que a taxa de conversão padrão especificado na configuração da unidade de negócios de compras, é Corporativa e não PTAX - Vendas",null,null,null,"ALTO",null,null,null,"Redwood",null,null,null,null,null,null],"agingFormula":true},{"id":"62","values":["larissa.amandio@ninecon.com.br","20/05/2026 14:34","4-0002834939 ","n/a","n/a","n/a","n/a","I am unable to add the Item structure name in a new work definition version","Manufacturing",140.3930555555562,"07/06 - Suporte compartilhou material para verificar como o produto funciona, aguardando retorno do consultor",null,null,"sim","ALTO",null,null,null,"Não existe no Planner",null,null,null,null,null,null],"agingFormula":true},{"id":"63","values":["leandro.cavalheiro@ninecon.com.br","20/05/2026 17:09","4-0002836010 ","n/a","n/a","n/a","n/a","BRADESCO PIX Layout Errors","LACLS",140.2854166666657,"03/06 - Suporte solicitou evidência e logs de erro, aguardando retorno do consultor",null,null,null,"Médio",null,null,null,"Não existe no Planner",null,null,null,null,null,null],"agingFormula":true},{"id":"64","values":["bruno.petroveski@ninecon.com.br","21/05/2026 02:43","4-0002838540 ","n/a","n/a","n/a","n/a","Excessive LOGSLS requests in OIC impacting the IDCS/IAM authentication process","LOGLS",139.88680555555766,"03/06 - Após OWC, suporte recomendou alguns ajustes, em validação com o consultor",null,null,null,"Médio",null,null,null,null,null,"No Log-LS está gerando excesso de requisições, exaurindo as conexões",null,null,null,null],"agingFormula":true},{"id":"65","values":["leandro.cavalheiro@ninecon.com.br","25/05/2026 15:37","4-0002868362 ","07/10/2026 14:27","Review Bug","2-Significant","Escalated","Unable to place Hold on AP Invoice Installments We are facing an issue in Payable…","Payables",135.3493055555591,"19/08 - ETA 02/Out  26/Out",null,"26/10/2026 00:00",null,"ALTO",null,"sim","sim","GCO#12","impacta rice","Processo está sendo feito manualmente, validar volumetria","Sim",null,null,null],"agingFormula":true},{"id":"66","values":["bruno.petroveski@ninecon.com.br","25/05/2026 17:44","4-0002868816 ","n/a","n/a","n/a","n/a","Excess of requests to IDCS originating from OIC, resulting in the inability to access the instance","Integration 3",135.26111111111095,"04/06 - Consultor retornou mais informações pra análise do suporte",null,null,null,"Médio",null,null,null,null,null,"Foi aberto para requisitar logs do OIC para análise da SR 4-0002838540 ",null,null,null,null],"agingFormula":true},{"id":"67","values":["roberto.costa@ninecon.com.br","26/05/2026 10:02","4-0002874487 ","n/a","n/a","n/a","n/a","No Go\" Issue: Incorrect Tax Recovery Handling in AP-PPM Integration","Project Costing",134.58194444444234,"07/07 - Consultor fará a tratativa deste problema através da SR 4-0002937648",null,null,"sim","ALTO",null,null,null,null,null,"Pedido: solicitação de OWC ou tracelog","sim",null,null,null],"agingFormula":true},{"id":"68","values":["guilherme.bermejo@ninecon.com.br","27/05/2026 19:54","4-0002888234 ","n/a","n/a","n/a","n/a","TaxFY Integration: Document integrated successfully but not appearing in FDC","Automated Invoice Processing",133.17083333332994,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"69","values":["guilherme.bermejo@ninecon.com.br","27/05/2026 20:04","4-0002888267 ","n/a","n/a","n/a","n/a","TaxFY Integration: Document integrated successfully but not appearing in FDC","Automated Invoice Processing",133.16388888889196,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"70","values":["guilherme.bermejo@ninecon.com.br","27/05/2026 20:29","4-0002888344 ","n/a","n/a","n/a","n/a","TaxFY Integration: Document integrated successfully but not appearing in FDC","Tax",133.1465277777752,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"71","values":["vanessa.breseghello@ninecon.com.br","28/05/2026 16:28","4-0002896076 ","n/a","n/a","n/a","n/a","LOGLS GFD – Canonical file generated with blank CIOT tags for Own Fleet MDF-e scenario","LOGLS",132.31388888888614,"12/06 - Patch de correção disponibilizado para testes",null,null,null,"ALTO",null,null,null,null,null,null,"sim",null,null,null],"agingFormula":true},{"id":"72","values":["leonardo.guilherme@ninecon.com.br","01/06/2026 09:14","4-0002917142 ","n/a","n/a","n/a","n/a","THE NDI AND DDI TAGS ARE NOT BEING POPULATED FROM THE XML FOR THE FDC","Inventory Management",128.6152777777752,"13/08 - Resolvido com Meni",null,null,"Sim","ALTO",null,"sim",null,"SAFX#49 - Bloco C120","Importação",null,"Sim",null,null,null],"agingFormula":true},{"id":"73","values":["leonardo.guilherme@ninecon.com.br","01/06/2026 23:04","4-0002922845 ","n/a","n/a","n/a","n/a","The transaction imported by autoinvoice with Rate but without tax Amount","Tax",128.03888888889196,"10/09 - Solicitar ao DEV o ETA","ERP/Fusion Tax",null,"Sim","ALTO",null,"sim","sim",null,"Impacta revenda de varejo (ex.: linguiça)\n80% da operação","Problema na contabilização quando a transação vem do OM, \"Ajuste - tarifa parte do zero\"","Sim",null,null,null],"agingFormula":true},{"id":"74","values":["guilherme.bermejo@ninecon.com.br","02/06/2026 09:48","4-0002927591","n/a","n/a","n/a","n/a","TaxFY Integration: Document integrated successfully but not appearing in FDC","Automated Invoice Processing",127.59166666666715,"02/06 - Suporte solicitou mais informações",null,null,null,"ALTO",null,null,null,null,null,"XML de combustível, não importa",null,null,null,null],"agingFormula":true},{"id":"75","values":["leonardo.guilherme@ninecon.com.br","03/06/2026 09:24","4-0002937648 ","n/a","n/a","n/a","n/a","AP DISTRIBUTION LINES ARE NOT SHOWING RECOVERABLE TAXES","Tax",126.60833333332994,"10/07 - Suporte retornou informações, aguardando retorno do consultor",null,null,"Sim","ALTO",null,null,null,null,null,null,"sim",null,null,null],"agingFormula":true},{"id":"76","values":["guilherme.bermejo@ninecon.com.br","03/06/2026 10:53","4-0002938554 ","n/a","n/a","n/a","n/a","TaxFY Integration: Document integrated successfully but not appearing in FDC","Supply Chain Financial",126.54652777777665,"17/07 - Consultor informou que atualização do CMK funcionou, solução em testes",null,null,"Sim","ALTO",null,null,null,"Não existe no Planner",null,"NF de compra de combustível","sim",null,null,null],"agingFormula":true},{"id":"77","values":["kassio.cezar@plumaagro.com.br","03/06/2026 15:58","4-0002941164 ","n/a","n/a","n/a","n/a","Issue's in forms 2.0","Planning and Budgeting",126.3347222222219,"18/06 -Aguardando fechamento da SR, problema resolvido",null,null,null,"Não Existe",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"78","values":["bruno.petroveski@ninecon.com.br","06/06/2026 08:13","4-0002963273 ","n/a","n/a","n/a","n/a","String size limit in LACLS - MFM","LACLS",123.65763888888614,"16/06 -Aguardando fechamento da SR, problema resolvido",null,null,null,"Não Existe",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"79","values":["bruno.petroveski@ninecon.com.br","09/06/2026 11:01","4-0002984795 ","n/a","n/a","n/a","n/a","Database Actions Service Unavailable Across All ATP Instances","Autonomous Database",120.54097222222481,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"80","values":["leandro.cavalheiro@ninecon.com.br","10/06/2026 10:57","4-0002995493 ","n/a","n/a","n/a","n/a","AP-810667 Error When Sending Requester via Payables REST API","Payables",119.54374999999709,"23/07 - Suporte orientou o consultor, aguardando execução do consultor",null,null,null,"Não Existe",null,null,null,"Impacta Ecomex",null,null,null,null,null,null],"agingFormula":true},{"id":"81","values":["larissa.amandio@ninecon.com.br","10/06/2026 15:43","4-0002997847 ","n/a","n/a","n/a","n/a","Work Definition - Duplicate/Triplicate records displayed in Operation Items","Maintenance",119.34513888888614,"12/06 - Solução oferecida em análise pelo consultor",null,null,null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"82","values":["guilherme.rodrigues@ninecon.com.org","11/06/2026 12:44","4-0003006931 ","n/a","n/a","n/a","n/a","#26B-A The customer requested the creation of a new button in a redwood page. When i opened the VBS pa…","Sourcing",118.46944444444671,"05/07 - Suporte questionou se ainda possuem este problema, aguardando retorno desde 11/06",null,null,null,"Médio",null,null,null,"Redwood (GCO#02, GCO#06, GCO#07) - Não existe no Planner",null,"Portal do fornecedor não pode usar o Classic",null,null,null,null],"agingFormula":true},{"id":"83","values":["leonardo.guilherme@ninecon.com.br","11/06/2026 15:37","4-0003008232 ","n/a","n/a","n/a","n/a","LACLS_EXTRACTAPSPEDDATA_INCREMENTAL IS NOT EXTRACTING THE TAX AMOUNTS CALCULATED FROM FDC","Tax",118.34930555555911,"20/08 - Solução oferecida, aguardando retorno do consultor",null,null,"Sim","ALTO",null,"sim",null,null,"compras de uso e consumo, CST 90, imposto está indo para a TR","Impacta as NF de ICMS CST 90","Sim",null,null,null],"agingFormula":true},{"id":"84","values":["leonardo.guilherme@ninecon.com.br","11/06/2026 17:19","4-0003008809 ","n/a","n/a","n/a","n/a","THE NOT IN OPERATOR IS NOT WORKING FOR WITHHELD TAXES","Tax",118.27847222222044,"10/07 - Agendada OWC para 13/Jul",null,null,"Sim","Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"85","values":["mateus.fetzner@plumaagro.com.br","12/06/2026 16:25","4-0003017154 ","07/10/2026 10:07","Review Update","2-Significant","Never escalated","#26B-A Error creating Redwood screen trading","Sourcing",117.31597222221899,"06/10 - Soluçãp validada em Test, será aplicada em Prod em 09/Out",null,"25/Set \n02/Out TBD","Sim","Médio","ALTO","durante",null,"Redwood","criação de modelo de negociação, não está funcionando com o tipo global","Estão tentando utilizar um modelo único, para todas as BUs, através do flex field Global","Sim",null,"Custo Zero",null],"agingFormula":true},{"id":"86","values":["vanessa.breseghello@ninecon.com.br","16/06/2026 16:28","4-0003044067 ","n/a","n/a","n/a","n/a","BUG:39595881:MDF-e XML Schema Validation Error – Incorrect/Missing Tags in Generated XML","LOGLS",113.31388888888614,"27/08 - Solução entregue pela Oracle em teste, necessário entrega da TR ETA 16/Set (cancelamento e encerramento)",null,null,null,"ALTO",null,"sim","sim",null,null,"Problema na emissão do MDFe de Frota Própria","sim",null,null,null],"agingFormula":true},{"id":"87","values":["bruno.petroveski@ninecon.com.br","17/06/2026 15:17","4-0003053581 ","n/a","n/a","n/a","n/a","Pack 26 - LACLS | ORA-20500: Other Exceptions: ORA-20500","LACLS",112.36319444444234,"19/06 - Foi compartilhado um plano de ação, aguardando retorno do consultor",null,null,null,"Não Existe",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"88","values":["paulo.cezar@ninecon.com.br","18/06/2026 12:44","4-0003061945 ","n/a","n/a","n/a","n/a","Supply Planning Number Format Not Respected","Supply Planning",111.46944444444671,"21/09 - Ambientes Pluma atualizados com a correção, validado em Test pelo consultor",null,null,null,"Médio",null,"sim","sim","Redwood","o campo está vindo no formato incorreto","Verificará se é um problema apenas da tela Redwood","Sim",null,null,null],"agingFormula":true},{"id":"89","values":["larissa.amandio@ninecon.com.br","18/06/2026 16:45","4-0003063566 ","n/a","n/a","n/a","n/a","Operation Items - New Row Not Displayed After Adding Item to Operation","Manufacturing",111.30208333333576,"31/07 - Patch foi testado e deu certo",null,null,null,"Médio",null,null,null,"Redwood",null,null,"Sim",null,null,null],"agingFormula":true},{"id":"90","values":["leonardo.guilherme@ninecon.com.br","23/06/2026 10:55","4-0003096523 ","n/a","n/a","n/a","n/a","FDC - XML OF THE COMPLEMENTARY PRICE FISCAL DOCUMENT IS BEING IMPORTED WITH THE TAX TYPE","Inventory Management",106.5451388888905,"14/08 - Em teste com o time Pluma desde 28/07, somente 1 layout funcionou, precisa levantar os demais layouts",null,null,"Sim","ALTO",null,"sim",null,null,"milho a fixar","Impacta o processo do milho a fixar, está fixando o tipo imposto não o tipo preço (NF complementar)","Sim",null,null,null],"agingFormula":true},{"id":"91","values":["guilherme.bermejo@ninecon.com.br","24/06/2026 10:16","4-0003106353 ","n/a","n/a","n/a","n/a","is not accepting the XML file with the group <veicProd>","Inventory Management",105.57222222222481,"15/07 - Consultor retornou mais informações, em análise com suporte",null,null,null,"Não Existe",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"92","values":["cmos-setup-user_ww@oracle.com","25/06/2026 17:19","4-0003119373 ","n/a","n/a","n/a","n/a","Web Conference June 29 at 1PM EST","Global Customer Hub",104.27847222222044,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"93","values":["cmos-setup-user_ww@oracle.com","25/06/2026 19:07","4-0003119968 ","n/a","n/a","n/a","n/a","Web Conference June 30 at 1PM EST","Global Customer Hub",104.20347222222335,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"94","values":["bruno.petroveski@ninecon.com.br","29/06/2026 07:36","4-0003137798 ","n/a","n/a","n/a","n/a","Autonomous Transaction Processing (ATP) Serverless instances were restarted","Autonomous Database Serverless",100.6833333333343,"06/07 - Consultor solicitou maiores detalhes sobre a manutenção que ocorreu no ambiente ATP",null,null,null,"Não Existe",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"95","values":["bruno.petroveski@ninecon.com.br","29/06/2026 10:47","4-0003139547 ","n/a","n/a","n/a","n/a","Business Object Resources REST API Documentation Not Available in OTM 26C (SaaS - OCI)","Transportation Management",100.55069444444234,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"96","values":["larissa.amandio@ninecon.com.br","29/06/2026 12:40","4-0003140592 ","n/a","n/a","n/a","n/a","Unable to Save Help Desk Request – \"Provide a valid value for BUOrgId","Help Desk",100.47222222221899,null,null,null,null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"97","values":["leandro.cavalheiro@ninecon.com.br","01/07/2026 11:35","4-0003163137 ","n/a","n/a","n/a","n/a","OIC Integration Adapter invokes incorrect child integration identifier, resulting in HTTP 404","LACLS",98.5173611111095,"07/07 - Em teste com o Antônio da Pluma",null,null,null,"Não Existe",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"98","values":["bruno.petroveski@ninecon.com.br","02/07/2026 10:03","4-0003172228 ","n/a","n/a","n/a","n/a","The OTM environment is unavailable for all users","Transportation Management",97.58125000000291,"06/07 - Suporte compartilhou um plano de ação, aguardando retorno do consultor",null,null,null,"Não Existe",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"99","values":["bruno.petroveski@ninecon.com.br","06/07/2026 14:12","4-0003198293 ","n/a","n/a","n/a","n/a","39474343: APPLYING LACLS_BR_MFM_DASHBOARD: CFOP MONITORING SCREEN WITH FREEZE","LACLS",93.40833333333285,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"100","values":["braulio.filho@ninecon.com.br","07/07/2026 13:07","4-0003208332 ","n/a","n/a","n/a","n/a","User can't view supplier responses data","Sourcing",92.45347222222335,"14/07 - Aguardando retorno do consultor do plano de ação compartilhado pelo suporte",null,null,null,"Não Existe",null,null,null,"Não existe no Planner",null,null,null,null,null,null],"agingFormula":true},{"id":"101","values":["leonardo.guilherme@ninecon.com.br","08/07/2026 11:31","4-0003218394 ","n/a","n/a","n/a","n/a","FDC DOES NOT CONSIDER THE ICMS_DESONERADO TAX AMOUNT","Inventory Management",91.52013888888905,"29/07 - Consultor retornou para o suporte, que o teste com valor calculado x NF não funcionou",null,null,"Sim","ALTO",null,null,null,null,null,"ICMS desonerado","Sim",null,null,null],"agingFormula":true},{"id":"102","values":["cmos-setup-user_ww@oracle.com","08/07/2026 14:42","4-0003220020 ","n/a","n/a","n/a","n/a","Need Brazilian Portuguese translation service during the meeting scheduled on Friday July 10 at 1.00pm ET","Global Customer",91.38749999999709,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"103","values":["cmos-setup-user_ww@oracle.com","09/07/2026 19:07","4-0003231782 ","09/07/2026 19:15","Close Requested","2-Significant","Never escalated","Unable to Save Help Desk Request – \"Provide a valid value for BUOrgId","Human Resources Help Desk",90.20347222222335,"10/07 0 SR colaborativa: 4-0003140592",null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"104","values":["larissa.amandio@ninecon.com.br","13/07/2026 14:05","4-0003254459 ","n/a","n/a","n/a","n/a","Unable to View Created Help Desk Requests","Help Desk",86.41319444444525,"12/08 - Foi compartilhado plano de ação, aguardando validação do consultor",null,null,"sim","ALTO",null,"sim",null,null,"impacta manutenção","Usuário não entra sem esta funcionalidade","Sim",null,null,null],"agingFormula":true},{"id":"105","values":["bruno.petroveski@ninecon.com.br",null,"4-0003255415 ","n/a","n/a","n/a","n/a","Unable to Access Database Actions","Autonomous Database Serverless",46303,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"106","values":["guilherme.bermejo@ninecon.com.br","13/07/2026 16:54","4-0003255578 ","n/a","n/a","n/a","n/a","AP DISTRIBUTION LINES ARE NOT SHOWING RECOVERABLE TAXES","LACLS",86.29583333332994,"17/08 - Solução oferecida, aguardando retorno do consultor - ETA Ninecon 09/Set 11/09",null,null,"Sim","ALTO",null,"sim","sim",null,"problema na compra de Ativo fixo, sensibilizando custo em projeto","Manual informa que os impostos precisam ser configurados como Self Assessed","Sim",null,null,null],"agingFormula":true},{"id":"107","values":["wendel.andrade@ninecon.com.br","14/07/2026 08:54","4-0003261732 ","02/09/2026 10:05","Cloud Deployment Scheduled","3-Standard","Never escalated","Refund - You must enter a CNPJ or CPF taxpayer identifier for the payee AR-856622","Receivables",85.6291666666657,"24/08 - ETA 26D - 07-Nov Test / 21-Nov Prod",null,"07/11/2026 00:00",null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"108","values":["bruno.petroveski@ninecon.com.br",null,"4-0003273700 ","n/a","n/a","n/a","n/a","Application service roles are not taking effect in Oracle Integration (OIC) (intermittent issue)","Oracle Integration 3",46303,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"109","values":["bruno.petroveski@ninecon.com.br","15/07/2026 17:35","4-0003277409 ","n/a","n/a","n/a","n/a","Service unavailability and intermittent issues across multiple services","Infrastructure",84.2673611111095,"17/07 - SR em análise com os suporte",null,null,null,"Não Existe",null,null,null,"Não existe no Planner",null,null,null,null,null,null],"agingFormula":true},{"id":"110","values":["guilherme.bermejo@ninecon.com.br","17/07/2026 16:19","4-0003296283 ","n/a","n/a","n/a","n/a","Air extractor returning incorrect lines","Inventory Management",82.32013888889196,"11/08 - Em validação com o time Pluma",null,null,"Sim","ALTO",null,"durante",null,null,"escrituração do contas a receber (preço de lista zero)",null,"Sim",null,null,null],"agingFormula":true},{"id":"111","values":["leonardo.guilherme@ninecon.com.br","20/07/2026 05:38","4-0003306724 ","10/09/2026 02:25","Awaiting Internal Response","2-Significant","Never escalated","ASSESSABLE VALUE FIELD NOT AVAILABLE IN THE UPDATE ONE LINE INBOUND FISCAL DOCUMENT REST API","Inventory Management",79.76527777777665,"07/10 - Idea 975953, ETA 27B, será realizada uma agenda com time de produto em 19/Out",null,"27B - Mai/27","Sim","ALTO",null,"durante",null,"Idea 877370 \nGRF#01","Impacta um estado - PR, retira o pedágio do Cte (4k~3k /mês)\nCrédito de IPI na importação (Ex.: NTT) tem um RPA para preencher este campo","Falta campos na nova API","Sim","Processo manual, volume alto (API)","Processo",null],"agingFormula":true},{"id":"112","values":["vanessa.chiochetta@ninecon.com.br","20/07/2026 11:05","4-0003309679 ","n/a","n/a","n/a","n/a","Payment Terms LOV is blank in Redwood Purchase Order page, but works in Classic UI","Purchasing",79.53819444444525,"28/07 - Será entregue na 26C",null,null,null,"ALTO",null,null,null,"Redwood",null,null,null,null,null,null],"agingFormula":true},{"id":"113","values":["jonatan.molossi@ninecon.com.br","20/07/2026 16:09","4-0003312223 ","07/10/2026 11:31","Close Requested","2-Significant","Never escalated","REDWOOD: Product Category field value disappears in Redwood after save - bug (39778963)","Order Management",79.32708333332994,"05/10 - Solução validada pelo consultor, Prod atualizada em 03/10",null,"11/09/2026\n25/Set  02/Out TBD",null,"Médio","Médio","sim","sim","Redwood","impacta reforma tributária (class trib) - Rice","Problema num campo core utilizado na reforma (DEV1 funciona)","Sim",null,"Custo Zero",null],"agingFormula":true},{"id":"114","values":["guilherme.bermejo@ninecon.com.br","21/07/2026 07:46","4-0003317995 ","n/a","n/a","n/a","n/a","HYAPTAX1 :Tax rule is not working as expected","Tax",78.67638888888905,"14/08 - Suporte retornou que está analisando o problema, em 11/08 fui informada que a SR será fechada, poderiam verificar? ",null,null,"sim","ALTO",null,"sim",null,"GCO#02 - cálculo do imposto na negociação","será No Go para SIT2 - SR nova","Erro quando a regra tem que utilizar o fornecedor como determinante","Sim",null,null,null],"agingFormula":true},{"id":"115","values":["alisson.gomide@ninecon.com.br","21/07/2026 11:49","4-0003320349 ","n/a","n/a","n/a","n/a","The OSP requisition is being created as approved and we need this to pass trought a BPM workflo…","Maintenance",78.50763888889196,"28/08 - Solicitamos apoio para ter a OWC",null,null,null,"Médio",null,null,null,null,null,"Usuário quer que a requisição passe por aprovação",null,null,null,null],"agingFormula":true},{"id":"116","values":["leandro.cavalheiro@ninecon.com.br","21/07/2026 16:19","4-0003322469 ","n/a","n/a","n/a","n/a","BRADESCO PIX | LACLS_BR_AP_BRA_240_PIX | NEW LAYOUT VALIDATION ERRORS AFTER BUG 39253896","LACLS",78.32013888889196,"13/08 - Aberto bug 39877913 para análise de DEV",null,null,null,"ALTO",null,"sim",null,"Bradesco PIX",null,null,"Sim",null,null,null],"agingFormula":true},{"id":"117","values":["cmos-setup-user_ww@oracle.com","21/07/2026 17:54","4-0003323010 ","21/07/2026 17:54","n/a","2-Significant","Never escalated","Redwood-Maintenance Program blank in Redwood; loads normally in Classic (Forms).","Maintenance",78.2541666666657,"21/07 - Criada para ajudar na SR 4-0002654057",null,null,null,null,null,null,null,"Redwood",null,null,null,null,null,null],"agingFormula":true},{"id":"118","values":["cmos-setup-user_ww@oracle.com","22/07/2026 04:22","4-0003326290 ","n/a","n/a","n/a","n/a","OWC 23JUL 10:15 AM ET","Global Customer Hub Services",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":false},{"id":"119","values":["vanessa.breseghello@ninecon.com.br","22/07/2026 10:12","4-0003329642 ","n/a","n/a","n/a","n/a","Association of CT-e and NFS-e to the Same OTM Shipment","LOGLS",77.57499999999709,"28/07 - Solução oferecida não pode ser testada enquanto SR não for resolvida",null,null,null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"120","values":["bruno.petroveski@ninecon.com.br","23/07/2026 10:52","4-0003340002 ","n/a","n/a","n/a","n/a","[DT]None of the scheduled jobs have been executed in ODT","Data Transforms",76.54722222222335,"24/07 - Suporte solicitou mais informações, aguardando consultor",null,null,null,"Não Existe",null,null,null,"Não existe no Planner",null,null,null,null,null,null],"agingFormula":true},{"id":"121","values":["bruno.petroveski@ninecon.com.br","23/07/2026 11:37","4-0003340515 ","n/a","n/a","n/a","n/a","OIC instance does not display all existing compartments in the tenancy","Oracle Integration 3",76.51597222222335,"10/08 - Solicitar Manage action na SR, informando deadline",null,null,null,"ALTO",null,null,null,"Idea: 945661",null,null,null,null,null,null],"agingFormula":true},{"id":"122","values":["braulio.filho@ninecon.com.br","23/07/2026 13:01","4-0003341294 ","n/a","n/a","n/a","n/a","Unable to see the tasks Manage Collection Documents and Manage Collection Documents Import","Payments",76.45763888888905,"10/08 - Solicitar Manage action na SR, informando deadline",null,null,null,"ALTO",null,null,null,"Impacto é no DEV2",null,null,null,null,null,null],"agingFormula":true},{"id":"123","values":["marcelo.silva@ninecon.com.br","23/07/2026 19:08","4-0003343616 ","05/10/2026 17:06","Solution Offered","2-Significant","De-escalated","MFM controls third-party inventory transactions using only LRU and CFOP (CFOP 5949)","LAD Add-on Localizations",76.20277777777665,"05/10 - Solução oferecida testada pelo consultor",null,"09/10/2026\nentregue - 28/09",null,"ALTO",null,"sim","sim","Controle de Terceiro\nGES#28 e GES#18","não movimentar estoque de terceiros, fazer o processo de forma manual (físico e contábil)",null,"sim","Segurará alguns cenários para testar a correção",null,null],"agingFormula":true},{"id":"124","values":["bruno.petroveski@ninecon.com.br","27/07/2026 10:23","4-0003366441 ","n/a","n/a","n/a","n/a","The Fusion environments became unavailable without any justification.","Service",72.5673611111124,"27/07 - Em análise com o suporte",null,null,null,"Baixo",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"125","values":["leandro.cavalheiro@ninecon.com.br","27/07/2026 12:14","4-0003367620 ","n/a","n/a","n/a","n/a","SAFRA - Erro validação no banco Safra - TED","LACLS",72.49027777777519,"18/08 - Aberto bug 39899398 para o time de DEV",null,null,null,"ALTO",null,"sim",null,"Safra TED",null,null,"Sim",null,null,null],"agingFormula":true},{"id":"126","values":["leandro.cavalheiro@ninecon.com.br","29/07/2026 16:53","4-0003390095 ","n/a","n/a","n/a","n/a","Inconsistent bank validation during Brazilian DDA collection document import","Payables",70.29652777777665,"14/08 - Solicitado ao consultor que insira o retorno do cliente na SR, para que possamos escalar a mesma",null,null,null,"Médio",null,null,null,"DDA \nCPR#12",null,null,null,null,null,null],"agingFormula":true},{"id":"127","values":["tania.silva@ninecon.com.br","30/07/2026 10:03","4-0003397317 ","n/a","n/a","n/a","n/a","Create Electronic Bank File Transfer Templates (CNABs) BANK CEF PIX","LACLS",69.58125000000291,"18/09 - Falta contratação da Finet",null,null,null,"ALTO",null,"sim","sim","CEF PIX",null,null,"Sim",null,null,null],"agingFormula":true},{"id":"128","values":["tania.silva@ninecon.com.br","30/07/2026 10:12","4-0003397403 ","n/a","n/a","n/a","n/a","ER:39816111: Create Electronic Bank File Transfer Templates (CNABs) BANK SICOOB PIX","LACLS",69.57499999999709,"18/09 - Falta contratação da Finet",null,null,null,"ALTO",null,"durante","sim","SICOOB PIX",null,null,"Sim",null,null,null],"agingFormula":true},{"id":"129","values":["tania.silva@ninecon.com.br","30/07/2026 10:16","4-0003397468 ","07/10/2026 14:00","Dev Investigating","3-Standard","Never escalated","ER:39816154: Create Electronic Bank File Transfer Templates (CNABs) BANK SICREDI PIX","LACLS",69.57222222222481,"02/10 - Foi aberto novo bug 40106931 ",null,"09/10/2026 00:00",null,"ALTO",null,"durante","sim","SICREDI PIX",null,null,"Sim",null,null,null],"agingFormula":true},{"id":"130","values":["tania.silva@ninecon.com.br","30/07/2026 10:19","4-0003397496 ","n/a","n/a","n/a","n/a","Create Electronic Bank File Transfer Templates (CNABs) BANK SISPRIME PIX","LACLS",69.57013888889196,"07/08 - Aguardando confirmação do banco",null,null,null,"Não Existe",null,"fechado",null,"SISPRIME PIX",null,null,"Sim",null,null,null],"agingFormula":true},{"id":"131","values":["guilherme.bermejo@ninecon.com.br","30/07/2026 11:57","4-0003398461 ","n/a","n/a","n/a","n/a","THE TAX DOCUMENT GOT STUCK WITH A \"VALIDATED\" STATUS","Inventory Management",69.50208333333285,"27/08 - ETA 27A",null,"27A",null,"ALTO",null,"não",null,"Redwood","investigação por conta de 3 NFs, o processo pode ser refeito como workaround",null,"Sim",null,null,null],"agingFormula":true},{"id":"132","values":["paulo.cezar@ninecon.com.br","30/07/2026 16:43","4-0003400785 ","n/a","n/a","n/a","n/a","Measure added to the layout are not displayed","Planning",69.3034722222219,"05/08 - OWC agendada para 06/08",null,null,null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"133","values":["paulo.cezar@ninecon.com.br","30/07/2026 16:56","4-0003400874 ","n/a","n/a","n/a","n/a","work order approval process for manufacturing and maintenaince","Maintenance",69.2944444444438,"05/08 - Consultor questionou se é possível aprovar por linha, por Header já funcionou",null,null,null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"134","values":["bruno.petroveski@ninecon.com.br","31/07/2026 11:47","4-0003408762 ","29/09/2026 09:43","Dev Fix in Progress","2-Significant","Never escalated","ODT Scheduled Jobs Were Not Executed","Data Transforms",68.5090277777781,"29/09 - ETA 10/Out - correção definitiva",null,"26/09\n10/Out",null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"135","values":["guilherme.bermejo@ninecon.com.br","31/07/2026 13:48","4-0003409806 ","07/10/2026 14:26","Review Update","2-Significant","Never escalated","Taxable Basis formula with Price Thresholds is not working with Product Fiscal Classification Type","Tax",68.42500000000291,"07/10 - Consultor Ninecon aguarda confirmações do time do suporte, para valida a solução oferecida",null,null,null,"ALTO",null,"sim","sim",null,"80% emissão de NF do MS (90% Belo)","Limita pedidos faturados abaixo da pauta (valor de mercado), gera multa (funcionou em DEV1)","Sim",null,null,null],"agingFormula":true},{"id":"136","values":["leonardo.guilherme@ninecon.com.br","31/07/2026 17:32","4-0003411384 ","n/a","n/a","n/a","n/a","THE AP LACLS EXTRACTOR IS NOT RETURNING G_LINES FOR COMPLEMENTARY INVOICES","LACLS",68.26944444444234,"11/08 - Aguardando retorno do consultor (Cheachire)",null,null,null,"ALTO",null,"sim",null,"GRF#06\nSAFX49 (processo)","final do processo do milho a fixar (c113 - safx48 e 49)",null,"Sim",null,null,null],"agingFormula":true},{"id":"137","values":["leonardo.guilherme@ninecon.com.br","03/08/2026 15:21","4-0003432548 ","n/a","n/a","n/a","n/a","FDC - TAX TYPE NOT APPEARS IN THE LINE DETAIL INFORMATION OF THE FISCAL ATTRIBUTE SCREEN","Inventory Management",65.36041666667006,"11/08 - Será fechada",null,null,null,"Médio",null,"não",null,null,null,null,"Sim",null,null,null],"agingFormula":true},{"id":"138","values":["paulo.cezar@ninecon.com.br","04/08/2026 13:05","4-0003442643 ","n/a","n/a","n/a","n/a","Auto-approval rule using empty approval group is not working for WorkOrderDeferredApproval","Oracle Business Process Management Suite",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":false},{"id":"139","values":["roberto.costa@ninecon.com.br","04/08/2026 13:15","4-0003442704 ","28/09/2026 09:15","Dev Investigating","3-Standard","De-escalated","INT: Rounding Error in FA_PRODUCTION_INTERFACE (Units of Production)","Assets",64.44791666666424,"05/10 - Solicitado priorização ao time DEV","ERP/Fusion Assets",null,null,"ALTO",null,null,null,"GAF#01","WA multiplicando por 100","Quando roda via FBDI trunca as casas decimais, pela tela ou planilha ADFI funciona",null,null,null,null],"agingFormula":true},{"id":"140","values":["tania.silva@ninecon.com.br","04/08/2026 14:51","4-0003443443 ","n/a","n/a","n/a","n/a","ERRO PARA VALIDAR LAYOUT BANCO DO BRASIL PIX - Somente para a empresa Mais Frango","LACLS",64.38124999999854,"05/08 - Esta com erro apenas na Mais Frango",null,null,null,"Não Existe",null,"sim",null,"BB PIX",null,null,"Sim",null,null,null],"agingFormula":true},{"id":"141","values":["tania.silva@ninecon.com.br","04/08/2026 15:21","4-0003443634 ","n/a","n/a","n/a","n/a","Erro na validação no Layout de arquivo para Boleto Banco Votorantim","LACLS",64.36041666667006,"14/08 - Consultor retornou mais dados para análise",null,null,null,"ALTO",null,"sim",null,"Votorantim Boleto e TED",null,null,"Sim",null,null,null],"agingFormula":true},{"id":"142","values":["bruno.petroveski@ninecon.com.br","05/08/2026 20:39","4-0003455826 ","n/a","n/a","n/a","n/a","Error during the application of LACLS Pack 26.3","LACLS",63.13958333332994,"07/08 - Aguardando retorno do consultor",null,null,null,"Médio",null,"fechada",null,null,"atualização das localizações",null,"Sim",null,null,null],"agingFormula":true},{"id":"143","values":["bruno.petroveski@ninecon.com.br","06/08/2026 07:50","4-0003460257 ","n/a","n/a","n/a","n/a","Question regarding the upcoming Fusion update that will require MFA","Service",62.673611111109494,"07/08 -Em análise com o suporte",null,null,null,"Baixo",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"144","values":["cmos-setup-user_ww@oracle.com","06/08/2026 11:14","4-0003462115 ","07/10/2026 13:26","n/a","2-Significant","Never escalated","dbms scheduler issues","Autonomous Database",62.53194444444671,"SR colaborativa: 4-0003408762 - ETA - 21/Ago ",null,null,null,"Não Existe",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"145","values":["vanessa.chiochetta@ninecon.com.br","06/08/2026 11:25","4-0003462218 ","06/10/2026 00:01","Customer Working","2-Significant","Never escalated","Purchase Orders Not Displayed Under 'Orders' Tab Unless OSCS Index Job Is Manually Re-Run","Purchasing",62.52430555555475,"06/10 - OWC agendada para 07/10",null,null,null,"Médio","Médio",null,null,"Redwood\nCPR#10","Customizar as regras de validação de preenchimento de campos _ Agenda Pluma","Visualizam os pedido em outra aba",null,null,"Levantar esforço do time Ninecon",null],"agingFormula":true},{"id":"146","values":["cmos-setup-user_ww@oracle.com","06/08/2026 13:26","4-0003463287 ","n/a","n/a","n/a","n/a","OWC AUG 10 - 330pm ET","Global Customer Hub",62.440277777779556,"09/08 - Aguardando retorno do consultor",null,null,null,"Não Existe",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"147","values":["marcelo.silva@ninecon.com.br","06/08/2026 13:36","4-0003463362 ","n/a","n/a","n/a","n/a","Enhancement Request - MFM Physical Opening by CPF/CNPJ and State Registration","Inventory Management",62.4333333333343,"07/08 - SR foi criada com o produto EBS, foi solicitado criar uma nova SR",null,null,null,"Não Existe",null,"sim",null,null,"controle de estoque físico, granja pertence a 1 CPF, vários IE (verificar se já estão usando o CNPJ alfa)",null,"Sim",null,null,null],"agingFormula":true},{"id":"148","values":["paulo.cezar@ninecon.com.br","06/08/2026 14:31","4-0003463777 ","n/a","n/a","n/a","n/a","Carrying cost calculation","Supply Planning",62.39513888888905,"11/08 - Em análise com o engenheiro",null,null,null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"149","values":["tania.silva@ninecon.com.br","07/08/2026 08:54","4-0003470531 ","n/a","n/a","n/a","n/a","Erro de envio de remessa Faturas de Concessionarias","LACLS",61.6291666666657,"07/08 - Após análise, suporte solicitou retorno do banco, pois informações não estão consistentes",null,null,null,"Não Existe",null,"sim",null,"Pagto Concesionarias",null,null,"Sim",null,null,null],"agingFormula":true},{"id":"150","values":["tania.silva@ninecon.com.br","07/08/2026 15:11","4-0003473496 ","n/a","n/a","n/a","n/a","Erro na geração de arquivo via QR CODE - Banco Itau","LACLS",61.36736111110804,"28/08 - Aguardando validação do banco",null,null,null,"ALTO",null,"sim",null,"Itau - QR Code",null,null,"Sim",null,null,null],"agingFormula":true},{"id":"151","values":["bruno.petroveski@ninecon.com.br","07/08/2026 15:39","4-0003473633 ","n/a","n/a","n/a","n/a","Load Data from Fusion Supply Chain Planning into FDI","FDI",61.3479166666657,"07/08 -Em análise com o suporte",null,null,null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"152","values":["marcelo.silva@ninecon.com.br","10/08/2026 16:58","4-0003490569 ","05/10/2026 16:56","Customer Working","2-Significant","Never escalated","Verification of Standard Functionality – MFM Physical Opening Using CPF/CNPJ + State Registration","LACLS",58.29305555555766,"05/10 - Solicitado ETA pra time de LACLS",null,null,null,"ALTO",null,"sim",null,"Controle de Terceiro\nMFM - Processo","Origem: Agrosys - controle de estoque físico, granja pertence a 1 CPF, vários IE (verificar se já estão usando o CNPJ alfa)",null,null,null,null,null],"agingFormula":true},{"id":"153","values":["tania.silva@ninecon.com.br","10/08/2026 17:32","4-0003490756 ","n/a","n/a","n/a","n/a","Banco CEF via TED - Rações Douramix erro na geração de arquivo","LACLS",58.26944444444234,"12/08 - Em análise com o suporte",null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"154","values":["paulo.cezar@ninecon.com.br","12/08/2026 12:10","4-0003509146 ","n/a","n/a","n/a","n/a","custom measure visualization failure","Supply Planning",56.49305555555475,"14/08 - Suporte solicitou mais informações para análise",null,null,null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"155","values":["vanessa.chiochetta@ninecon.com.br","12/08/2026 16:00","4-0003510819 ","n/a","n/a","n/a","n/a","Product Fiscal Classification (NCM) LOV on Redwood Purchase Schedules Does Not Return Valid Codes","Purchasing",56.33333333333576,"13/09 - Corrigido na 27A, solicitar backport para 26C",null,"27A",null,"Médio","ALTO",null,null,"Redwood",null,"Aplicar CWB",null,null,null,null],"agingFormula":true},{"id":"156","values":["leonardo.guilherme@ninecon.com.br","13/08/2026 05:55","4-0003515667 ","n/a","n/a","n/a","n/a","FDG SHIP AUTOMATION NOT AUTOMATICALLY DERIVING ICMS ST INFORMATION","LACLS",55.75347222221899,"04/09 - Solução encontrada durante OWC, patch do produto será oficialmente entregue",null,null,"Sim","ALTO",null,"sim","sim","Impacto fiscal\nSetup","Impacta revenda de varejo (ex.: linguiça)\n80% da operação","Problema no cálculo do imposto de operações que possuem ICMS-ST, não tenho o % de impacto","sim",null,null,null],"agingFormula":true},{"id":"157","values":["guilherme.bermejo@ninecon.com.br","13/08/2026 07:05","4-0003516310 ","06/10/2026 15:19","Customer Working","2-Significant","Never escalated","Rule does not calculate when a specific catalog is selected.","Tax",55.704861111109494,"04/10 - ETA 26D - 06/Nov","ERP/Fusion Tax","26D - 06/Nov",null,"ALTO",null,"sim","sim","GCO#02 - cálculo do imposto na negociação","será No Go para SIT2 - SR nova\n70% das negociações dependem desta integração","Erro quando a regra tem que utilizar o fornecedor como determinante","Sim",null,null,null],"agingFormula":true},{"id":"158","values":["guilherme.bermejo@ninecon.com.br","13/08/2026 07:21","4-0003516424 ","n/a","n/a","n/a","n/a","REDWOOD: FDC Redwood screens with long response times","Inventory Management",55.693749999998545,"21/08 - Esta funcionalidade será liberada em nova release, favor solicitar na SR quando isso ocorrerá",null,null,null,"ALTO",null,"sim",null,"Redwood","lentidão no uso das telas do FDC no Redwood",null,"Sim",null,null,null],"agingFormula":true},{"id":"159","values":["guilherme.bermejo@ninecon.com.br","13/08/2026 07:32","4-0003516528 ","n/a","n/a","n/a","n/a","THE FDC REDWOOD SCREEN REVERTS TO THE CLASSIC VIEW WHEN SWITCHING THE INTERFACE TO THE FISCAL DOCUME","Inventory Management",55.68611111111386,"17/09 - Suporte está verificando backport para 26C",null,"18/09\n27A ",null,"ALTO",null,"sim","sim","Redwood","aparece tela classic apesar de estar com Redwood",null,"Sim",null,"pendente usuário Pluma",null],"agingFormula":true},{"id":"160","values":["vanessa.chiochetta@ninecon.com.br","13/08/2026 09:32","4-0003517571 ","07/10/2026 11:39","Cloud Deployment Scheduled","2-Significant","Never escalated","Purchase Order Schedules: Fiscal Attribute Columns Not Available in View Mode (Redwood)","Purchasing",55.6027777777781,"23/09 - Bug 39991905 that issue will be solve in 26D.",null,"26D - 06/Nov",null,"Médio","ALTO",null,null,"Redwood\nCPR#10","Customizar as regras de validação de preenchimento de campos _ Agenda Pluma","usuário precisa informar uso pretendido e NCM, não aparecem na consulta, tem que clicar em alterar",null,null,"Levantar esforço do time Ninecon",null],"agingFormula":true},{"id":"161","values":["tania.silva@ninecon.com.br","13/08/2026 16:03","4-0003520805 ","n/a","n/a","n/a","n/a","Impostos ITAU - Validação de Layout TAX Arquivo com erro","LACLS",55.33125000000291,"14/08 - Layout em validação com o cliente",null,null,null,"Não Existe",null,null,null,"Itaú - Tax",null,null,null,null,null,null],"agingFormula":true},{"id":"162","values":["tania.silva@ninecon.com.br","13/08/2026 16:12","4-0003520861 ","n/a","n/a","n/a","n/a","Impostos CAIXA - Validação de Layout TAX Arquivo com erro","LACLS",55.32499999999709,"14/08 - Compartilhado plano de ação, aguardando consultor",null,null,null,"Não Existe",null,null,null,"Caixa - Tax",null,null,null,null,null,null],"agingFormula":true},{"id":"163","values":["tania.silva@ninecon.com.br","13/08/2026 16:23","4-0003520918 ","n/a","n/a","n/a","n/a","Impostos Bradesco - Validação de Layout TAX Arquivo com erro","LACLS",55.317361111112405,"14/08 - Consultora retornou que não foi possível realizar o plano de ação",null,null,null,"Não Existe",null,null,null,"Bradesco - TAX",null,null,null,null,null,null],"agingFormula":true},{"id":"164","values":["tania.silva@ninecon.com.br","13/08/2026 16:29","4-0003520963 ","n/a","n/a","n/a","n/a","Impostos DARF Banco do Brasil - Validação de Layout para Pagamento Sem Código de Barras","LACLS",55.31319444444671,"20/08 - Compartilhado plano de ação, aguardando retorno do consultor",null,null,null,"Não Existe",null,null,null,"BB - sem cód barras",null,null,null,null,null,null],"agingFormula":true},{"id":"165","values":["mateus.fetzner@plumaagro.com.br","14/08/2026 14:17","4-0003528989 ","n/a","n/a","n/a","n/a","Add 'Favorites' shortcut menu for quick access to reports/analyses (like classic screen)","Purchasing",54.40486111111386,"14/08 - Suporte informou que funcionalidade não está disponível",null,null,null,"ALTO",null,null,null,"Redwood",null,null,null,null,null,null],"agingFormula":true},{"id":"166","values":["larissa.amandio@ninecon.com.br","14/08/2026 15:31","4-0003529428 ","n/a","n/a","n/a","n/a","Unable to Save New Help Desk Request – LOV_BUOrgId Binding Error","Help Desk",54.35347222222481,"14/08 - Plano de ação compartilhado do AI Agent, aguardando consultor",null,null,null,"Não Existe",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"167","values":["leandro.cavalheiro@ninecon.com.br","14/08/2026 16:18","4-0003529680 ","n/a","n/a","n/a","n/a","Automatic Void Payment integration completes successfully but payments are not voided","LACLS",54.32083333333139,"14/08 - Compartilhado um plano de ação, aguardando consultor",null,null,null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"168","values":["tania.silva@ninecon.com.br","18/08/2026 12:02","4-0003554555 ","n/a","n/a","n/a","n/a","SICREDI Erro de Validação de Impostos com Código de Barras","LACLS",50.49861111111386,"20/08 - Compartilhado plano de ação, aguardando retorno do consultor",null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"169","values":["tania.silva@ninecon.com.br","19/08/2026 17:00","4-0003568242 ","n/a","n/a","n/a","n/a","ER:39911260:Banco do Brasil Pagamento de FGTS via Pix QR Code (FGTS Digital)","LACLS",49.29166666666424,"23/09 - Solução em teste com banco",null,"22/09/2026 00:00",null,"ALTO",null,null,"sim","BB - Pix QRCODE",null,null,"sim",null,null,null],"agingFormula":true},{"id":"170","values":["leandro.cavalheiro@ninecon.com.br","24/08/2026 11:57","4-0003603382 ","n/a","n/a","n/a","n/a","CEF Bank Return Import fails because JLBR_RETURN_ID sent in payment file does not match ERP Return N","LACLS",44.50208333333285,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"171","values":["tania.silva@ninecon.com.br","24/08/2026 15:42","4-0003605227 ","n/a","n/a","n/a","n/a","BRADESCO Impostos com Código de BARRAS Erro de retorno","LACLS",44.34583333333285,"26/08 - Contrato foi assinado com o banco, banco retornará a partir de 27/08",null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"172","values":["leandro.cavalheiro@ninecon.com.br","24/08/2026 17:21","4-0003605897 ","n/a","n/a","n/a","n/a","Santander Return File Fails with BPEL_SELECTION_FAILURE Due to Zero Payment Date","Latin America Cloud Local Solution (LACLS)",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":false},{"id":"173","values":["tania.silva@ninecon.com.br","25/08/2026 18:56","4-0003617005 ","n/a","n/a","n/a","n/a","BANRISUL PIX Remessa e Retorno BU Mais Frango","LACLS",43.21111111110804,"14/09 - Precisa fechar o contrato com a Finet para pagamento PIX do Banrisul",null,null,null,"ALTO",null,null,null,"Banrisul Pix",null,null,null,null,null,null],"agingFormula":true},{"id":"174","values":["tania.silva@ninecon.com.br","26/08/2026 09:59","4-0003622806 ","07/10/2026 13:27","Solution Offered","2-Significant","Never escalated","SAFRA erro de Remessa PLUSVAL para PIX","LACLS",42.58402777777519,"30/09 - Em tratativa com a Finet",null,"09/10/2026 00:00",null,"ALTO",null,null,null,"Safra - Plusval",null,null,null,null,null,null],"agingFormula":true},{"id":"175","values":["paulo.cezar@ninecon.com.br","26/08/2026 11:58","4-0003623914 ","07/10/2026 09:07","Review Update","2-Significant","Never escalated","Supply Planning: administer planning security","Supply Planning",42.50138888888614,"06/10 - Solução será entregue na tela Redwood, backport solictado para 26D",null,"27A - Fev/27",null,"Médio",null,null,null,null,null,"Regra de segurança para restringir o planejador ao que precisa acessar",null,null,null,null],"agingFormula":true},{"id":"176","values":["guilherme.bermejo@ninecon.com.br","26/08/2026 17:58","4-0003626586 ","07/10/2026 10:43","Customer Working","2-Significant","Never escalated","The API is not checking the supplier's tax classification to calculate taxes.","Tax",42.25138888888614,"04/10 - ETA 26D - 06/Nov",null,"26D - 06/Nov",null,"ALTO",null,null,null,"GCO#02 - cálculo do imposto",null,null,null,null,null,null],"agingFormula":true},{"id":"177","values":["leandro.cavalheiro@ninecon.com.br","28/08/2026 10:59","4-0003642374 ","n/a","n/a","n/a","n/a","CEF Bank Return Import fails because JLBR_RETURN_ID sent in payment file does not match ERP Return N","Financials",40.54236111111095,"28/08 - Em análise com o suporte",null,null,null,"ALTO",null,null,null,"CEF - Retorno bancário",null,null,null,null,null,null],"agingFormula":true},{"id":"178","values":["leandro.cavalheiro@ninecon.com.br","28/08/2026 11:08","4-0003642441 ","n/a","n/a","n/a","n/a","Daycoval - Error Processing Bank Return File – JGTMONTH Function","LACLS",40.536111111112405,"18/09 - Usuária informou que deu erro na solução oferecida, será compartilhado com o consultor",null,"11/09/2026 00:00",null,"ALTO",null,null,null,"Daycoval - Retorno bancário",null,null,null,null,null,null],"agingFormula":true},{"id":"179","values":["leandro.cavalheiro@ninecon.com.br","28/08/2026 11:10","4-0003642467 ","n/a","n/a","n/a","n/a","Error Processing Bank Return File – JGTMONTH Function – Safra","LACLS",40.53472222221899,"18/09 - Retornou problema na Finet",null,"11/09/2026 00:00",null,"ALTO",null,null,null,"Safra - Retorno bancário",null,null,null,null,null,null],"agingFormula":true},{"id":"180","values":["leandro.cavalheiro@ninecon.com.br","28/08/2026 15:05","4-0003644123 ","n/a","n/a","n/a","n/a","We have a supplier with one headquarters CNPJ and multiple branch CNPJs.","LACLS",40.37152777778101,"28/08 - Em análise com o suporte",null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"181","values":["leandro.cavalheiro@ninecon.com.br","28/08/2026 15:30","4-0003644259 ","n/a","n/a","n/a","n/a","Brazil CNAB Uses Legal Entity CNPJ Instead of Branch CNPJ for Internal Bank Account","Financials",40.35416666666424,"28/08 - Em análise com o suporte",null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"182","values":["bruno.petroveski@ninecon.com.br","28/08/2026 15:34","4-0003644281 ","n/a","n/a","n/a","n/a","ODT service end extremely slow","Autonomous Database",40.35138888889196,"22/09 - Problema foi resolvido, chamado continua aberto para validação",null,null,null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"183","values":["leandro.cavalheiro@ninecon.com.br","31/08/2026 14:27","4-0003659979 ","n/a","n/a","n/a","n/a","Brazil Localization Sicredi CNAB 240 bank return loads BD and 00 but validates only BD","Financials",37.39791666666861,"04/09 - Aguardando consultor Ninecon",null,null,null,"ALTO",null,null,null,"SICRED - Retorno bancário",null,null,null,null,null,null],"agingFormula":true},{"id":"184","values":["alisson.gomide@ninecon.com.br","01/09/2026 09:26","4-0003667607 ","n/a","n/a","n/a","n/a","OSP requisition that are created are automatically approved; we need them to go through the BPM","Self Service Procurement",36.6069444444438,"09/09 - Foi solicitada a confirmação do suporte quanto a funcionalidade (funciona ou não)",null,null,null,"Médio",null,null,null,"BPM",null,null,null,null,null,null],"agingFormula":true},{"id":"185","values":["vera.aveiro@ninecon.com.br","01/09/2026 09:38","4-0003667753 ","29/09/2026 14:32","Dev Investigating","2-Significant","Never escalated","Error in entry cost value for third-party items held by the company - MFM - Brazil","LACLS",36.598611111112405,"29/09 - Aberto Bug 39905547, em análise com DEV",null,null,null,"Médio",null,null,null,"GES#28","Ação: Descongelar a GES#28 (ETA 08/10), recomendável ter via produto (sim ou não?), bloco H (Oracle)","MFM - não considera o valor da NF, usa o mesmo valor do item, solicitado por outro cliente, verificar com o Meni. Custom não alterará o extrator, será feito somente na ordem de produção",null,null,null,null],"agingFormula":true},{"id":"186","values":["vera.aveiro@ninecon.com.br","01/09/2026 10:53","4-0003668617 ","n/a","n/a","n/a","n/a","Invoices for third-party control—such as CFOP codes 1901/1902/1903 or 2901/2902/2903—are receiv…","LACLS",36.546527777776646,"17/09 - Suporte confirmou a solução entregue",null,null,null,"Médio",null,null,null,"GES#09","Ação: Descongelar a GES#09 (contabilização) (sim ou não?) (Oracle)","problema de contabilização da NF: bookkeeping, no recebimento",null,null,null,null],"agingFormula":true},{"id":"187","values":["bruno.petroveski@ninecon.com.br","01/09/2026 18:36","4-0003672317 ","n/a","n/a","n/a","n/a","Intermittent Errors When Calling Fusion APIs","Oracle Fusion Service Cloud Service",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":false},{"id":"188","values":["bruno.petroveski@ninecon.com.br","02/09/2026 09:16","4-0003678233 ","n/a","n/a","n/a","n/a","Error when attempting to access an ATP instance using a client","Autonomous Database",35.61388888888905,"04/09 - Aguardando consultor Ninecon",null,null,null,"Baixo",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"189","values":["vanessa.chiochetta@ninecon.com.br","02/09/2026 11:43","4-0003679788 ","07/10/2026 13:33","Dev Investigating","2-Significant","Never escalated","fa-prc-pa Index Error Prevents Purchase Agreements from Appearing in Requisition LOV","Self Service Procurement",35.51180555555766,"07/10 - Foi criado o Bug 40124796",null,null,null,"ALTO","Muito Alto",null,null,"Redwood","Impossibilita usar o Redwood","não está sendo possível vincular a requisição ao acordo (LOV)",null,null,null,null],"agingFormula":true},{"id":"190","values":["cmos-setup-user_ww@oracle.com","02/09/2026 12:12","4-0003680068 ","02/09/2026 12:13","n/a","3-Standard","Never escalated","TAX RULE WITH PARTY FISCAL CLASSIFICATION DETERMINING FACTOR CLASS IS NOT WORKING","Oracle Fusion Tax Cloud Service",35.49166666666861,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"191","values":["leonardo.guilherme@ninecon.com.br","02/09/2026 15:41","4-0003681724 ","06/10/2026 22:01","Customer Working","2-Significant","Never escalated","FDC – NF COMPLEMENTARY PRICE INVOICE – DISCREPANCY BETWEEN XML ITEM AMOUNT AND FD LINE AMOUNT","Inventory Management",35.346527777779556,"06/10 - Suporte aguarda retorno do consultor Ninecon",null,null,null,"ALTO",null,null,null,"NF complementar",null,"NF complementar (milho a fixar) divergência entre preço no XML e importado no FDC",null,null,null,null],"agingFormula":true},{"id":"192","values":["leonardo.guilherme@ninecon.com.br","02/09/2026 17:36","4-0003682522 ","n/a","n/a","n/a","n/a","G_LINES GROUP NOT AVAILABLE IN AP LACLS_EXTRACTAPSPEDDATA_INCREMENTAL EXTRACTOR","LACLS",35.26666666667006,"04/09 - Aguardando consultor Ninecon",null,null,null,"ALTO",null,null,null,"Sped",null,null,null,null,null,null],"agingFormula":true},{"id":"193","values":["alisson.gomide@ninecon.com.br","04/09/2026 14:24","4-0003702710 ","05/10/2026 22:36","Solution Offered","3-Standard","Never escalated","26C- Redwood Sourcing, There is no option to go back when accessing the Monitor Negotiation page.","Sourcing",33.400000000001455,"11/09 - Suporte informou que esta funcionalidade é uma melhoria, solicitou votação no Idea 975050",null,null,null,"Baixo","Médio",null,null,"Redwood\nGCO#02 - Imposto, \nGCO#06 - Frete e \nGCO#07 - mapa comparativo","problema operacional, perde funionalidade de validação","Na tela de monitorar negociação, não existe um botão para voltar na tela anterior (tela classica existe)",null,null,"Levantar esforço do time Ninecon","https://community.oracle.com/customerconnect/discussion/975050/enhancement-request-introduce-a-done-button-on-the-redwood-sourcing-monitor-negotiations-screen"],"agingFormula":true},{"id":"194","values":["alisson.gomide@ninecon.com.br","04/09/2026 14:40","4-0003702859 ","n/a","n/a","n/a","n/a","26C - Process Requisitions - Saved Search has bugs","Purchasing",33.388888888890506,"10/09 - Solicitado mais informações para consultor",null,null,null,"Médio","Médio",null,null,"Redwood",null,"impacta nas pesquisas comuns do procurement (tela clássica funciona)",null,null,null,null],"agingFormula":true},{"id":"195","values":["alisson.gomide@ninecon.com.br","04/09/2026 15:34","4-0003703609 ","05/10/2026 15:52","Customer Working","3-Standard","Never escalated","26C - Redwood Sourcing - Synopsis text with an error","Sourcing",33.35138888889196,"05/10 - Suporte compartilhou um plano de ação, aguardando validação do consultor",null,null,null,"Baixo","Baixo",null,null,"Redwood","perde funcionalidade de validação",null,null,null,null,null],"agingFormula":true},{"id":"196","values":["alisson.gomide@ninecon.com.br","04/09/2026 16:21","4-0003704177 ","05/10/2026 13:52","Review Update","2-Significant","Never escalated","26C - Redwood Supplier Portal - It is not possible to view the ship-to location address.","Supplier Portal",33.318749999998545,"03/10 - Em análise com o suporte",null,null,null,"Médio","ALTO",null,null,"Redwood","não perde funcionalidade","Impacta na visualização do local de entrega, na clássica funciona",null,null,null,null],"agingFormula":true},{"id":"197","values":["gisieli.cabral@ninecon.com.br","04/09/2026 16:25","4-0003704194 ","06/10/2026 00:06","Close Requested","2-Significant","Never escalated","REDWOOD - Header-Level Extensible Flexfield (EFF) Values Not Persisted After Save/Submit","Order Management",33.31597222221899,"28/09 - Solução testada e aplicada nos ambientes da Pluma, solicitar fechamento da SR",null,null,null,"Médio","ALTO",null,null,"Redwood",null,"Impacta na atualização de campos flex no Redwood, tela Classic funciona (após 26C)",null,null,"Custo Zero",null],"agingFormula":true},{"id":"198","values":["leandro.cavalheiro@ninecon.com.br","08/09/2026 09:08","4-0003725872 ","24/09/2026 11:34","Awaiting Internal Response","2-Significant","Never escalated","Brazil Localization Sicredi CNAB 240 bank return loads BD and 00 but validates only BD","Payables",29.619444444440887,"05/10 - Solicitado escalation interno, solicitar na SR também",null,null,null,"ALTO",null,null,null,"SICRED - Retorno bancário",null,null,null,null,null,null],"agingFormula":true},{"id":"199","values":["roberto.costa@ninecon.com.br","08/09/2026 12:26","4-0003727735 ","06/10/2026 21:56","Customer Working","2-Significant","Never escalated","Oracle Core Solution Required for High-Volume Maintenance of Fixed Assets Transfer Control – Brazil","Financials for the Americas",29.481944444443798,"24/09 - Suporte informou que não existe este tipo de carga de dados, SR precisa ser fechada",null,null,null,"ALTO",null,null,null,"Setup FA","Setup do Asset com FDG, API não está exportando todos os dados para concluir a configuração (empresas onda 1)","API com problema",null,null,null,null],"agingFormula":true},{"id":"200","values":["guilherme.bermejo@ninecon.com.br","09/09/2026 10:54","4-0003737353 ","06/10/2026 16:06","Review Update","2-Significant","Never escalated","26C FDC: THE FD DOES NOT DERIVE THE PURCHASE ORDER WHEN THE ITEM IS AN EXPENSE ITEM","Inventory Management",28.545833333329938,"05/10 - Solução oferecida via e-mail em validação do consultor",null,null,null,"ALTO",null,null,"sim","FDC - NF importação direta \nSAFX49","FDC - Entrada de NF importação direta",null,"Sim",null,null,null],"agingFormula":true},{"id":"201","values":["leandro.cavalheiro@ninecon.com.br","11/09/2026 14:59","4-0003759259 ","07/10/2026 09:37","Solution Offered","2-Significant","Never escalated","ER:40015967: SICREDI - Error Processing Bank Return File – JGTMONTH Function","LACLS",26.375694444446708,"07/10 - Em teste com o cliente desde 29/Set",null,"30/09/2026 00:00",null,"ALTO",null,null,null,"SICRED - Retorno bancário",null,null,null,null,null,null],"agingFormula":true},{"id":"202","values":["leonardo.guilherme@ninecon.com.br","11/09/2026 17:48","4-0003760230 ","n/a","n/a","n/a","n/a","ERROR WHILE TRYING TO UPLOAD THE LACLS","LACLS",26.258333333331393,"18/09 -Aberto um bug 40046111 para DEV",null,"30/09/2026 00:00",null,"ALTO",null,null,null,"Setup Fiscal",null,null,null,null,null,null],"agingFormula":true},{"id":"203","values":["rosangela.nakano@ninecon.com.br","14/09/2026 11:43","4-0003772981 ","26/09/2026 16:53","Review Update","2-Significant","Never escalated","Error-The transfer order information for shipment transactions is missing in the Costing application","Cost Management",23.511805555557657,"07/10 - Solicitar manage review",null,null,null,"Médio",null,null,null,null,"Transferência concluída está solicitando NF",null,null,null,null,null],"agingFormula":true},{"id":"204","values":["leandro.cavalheiro@ninecon.com.br","14/09/2026 16:37","4-0003774918 ","n/a","n/a","n/a","n/a","Brazil Localization Sicredi CNAB 240 bank return loads BD and 00 but validates only BD","Latin America Cloud Local Solution (LACLS)",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":false},{"id":"205","values":["leandro.cavalheiro@ninecon.com.br","16/09/2026 14:35","4-0003793638 ","n/a","n/a","n/a","n/a","Brazil Localization Sicredi CNAB 240 bank return loads BD and 00 but validates only BD","Oracle Fusion Financials for the Americas",21.392361111109494,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"206","values":["leonardo.guilherme@ninecon.com.br","17/09/2026 15:43","4-0003804666 ","n/a","n/a","n/a","n/a","AR LACLS EXTRACTOR - UNEXPECTED BEHAVIOR FOR ICMS_DESONERADO TAX AMOUNT AND TAX RATE","LACLS",20.34513888888614,"22/09 - Suporte retornou que está OK, aguardando TR 198579",null,null,null,"ALTO",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"207","values":["vanessa.chiochetta@ninecon.com.br","17/09/2026 17:39","4-0003805373 ","n/a","n/a","n/a","n/a","Automatic reassessment isn't triggered after supplier requalification – Sourcing eligibility remains","Supplier Qualification",20.264583333329938,"21/09 - Consultora informou que está rodando testes para coletar as evidências",null,null,null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"208","values":["vanessa.chiochetta@ninecon.com.br","17/09/2026 17:58","4-0003805506 ","n/a","n/a","n/a","n/a","Unable to hide FOB and Freight Terms fields using Business Rules in Redwood Edit Purchase Order","Purchasing",20.25138888888614,"21/09 - Consultora respondeu para o suporte, em análise",null,null,null,"Médio",null,null,null,"Redwood",null,null,null,null,null,null],"agingFormula":true},{"id":"209","values":["rosangela.nakano@ninecon.com.br","19/09/2026 11:23","4-0003816847 ","23/09/2026 08:15","Review Update","2-Significant","Never escalated","Value Adjustment and Opening Cost Override transactions are not displayed in Redwood Review Item Cos","Cost Management",18.525694444440887,"07/10 - Solicitar manage review",null,null,null,"Médio",null,null,null,"Redwood","Impacto no uso do Redwood",null,null,null,null,null],"agingFormula":true},{"id":"210","values":["paulo.cezar@ninecon.com.br","21/09/2026 09:00","4-0003826362 ","06/10/2026 23:54","Dev Investigating","2-Significant","Never escalated","number format in redwood forms in manufacturing","Manufacturing",16.625,"04/10 - DEV está trabalhando na correção",null,null,null,"Médio",null,null,null,"Redwood",null,null,null,null,null,"Erro"],"agingFormula":true},{"id":"211","values":["bruno.petroveski@ninecon.com.br","21/09/2026 13:03","4-0003828780 ","07/10/2026 10:27","Customer Working","2-Significant","Never escalated","The log files are not purged even after ODT load with retention set","Database",16.45625000000291,"07/10 - Suporte solicitou mais informações, aguardando consultor Ninecon",null,null,null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"212","values":["douglas.sampaio@ninecon.com.br","21/09/2026 15:25","4-0003830051 ","n/a","n/a","n/a","n/a","Oracle OTM rest api TransmissionReports/logs not showing IMessageText fields"," Transportation",16.357638888890506,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"213","values":["douglas.sampaio@ninecon.com.br","21/09/2026 15:40","4-0003830174 ","n/a","n/a","n/a","n/a","Oracle OTM XML AckSpec now triggering external system for transmission report"," Transportation",16.34722222221899,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"214","values":["guilherme.bermejo@ninecon.com.br","21/09/2026 17:10","4-0003830879 ","n/a","n/a","n/a","n/a","Cleaning up rules and formulas in the environment","Oracle Fusion Tax Cloud Service",16.28472222221899,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"215","values":["tania.silva@ninecon.com.br","21/09/2026 15:53","4-0003830292 ","06/10/2026 10:08","Customer Working","2-Significant","Never escalated","Banco Daycoval - Erro na Importação do Arquivo Retorno Bancário","LACLS",16.338194444440887,"06/10 - Suporte aguarda confirmação do layout bancário junto ao Daycoval",null,null,null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"217","values":["cmos-setup-user_ww@oracle.com","21/09/2026 20:09","4-0003831856 ","n/a","n/a","n/a","n/a","Request Conference Translation for Zoom meeting: 5/23(Wed) 14:30 - 15:30 EST","Global Customer Hub Services",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":false},{"id":"218","values":["rosangela.nakano@ninecon.com.br","22/09/2026 16:06","4-0003840680 ","06/10/2026 13:51","Customer Working","2-Significant","Never escalated","Brazil FDC – Fiscal Document Receipt for Free-of-Charge Transaction Fails in Cost Accounting","Cost Management",15.329166666670062,"06/10 - Suporte aguarda retorno do consultor Ninecon",null,null,null,"Médio",null,null,null,null,"Processo de bonificação",null,null,null,null,null],"agingFormula":true},{"id":"219","values":["leonardo.guilherme@ninecon.com.br","22/09/2026 16:21","4-0003840779 ","n/a","n/a","n/a","n/a","Delete all rules created in the Manage Tax Rate and Manage Tax Formula tasks","Tax",15.318749999998545,"23/09 - Suporte retornou que não é possível excluir os dados da tabela",null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"220","values":["alisson.gomide@ninecon.com.br","22/09/2026 17:30","4-0003841218 ","03/10/2026 16:42","Review Update","2-Significant","Never escalated","26C - Redwood Purchasing, Conditions not being respected when leaving required fields","Purchasing",15.270833333335759,"03/10 - Em análise com o suporte",null,null,null,"ALTO",null,null,null,"Redwood","Customizar as regras de validação de preenchimento de campos _ Agenda Pluma","Campos obrigatórios não estão sendo respeitadas as condições",null,null,null,null],"agingFormula":true},{"id":"221","values":["rosangela.nakano@ninecon.com.br","23/09/2026 12:00","4-0003850781 ","06/10/2026 08:21","Review Update","2-Significant","Never escalated","How to Configure Consigned Inventory with Periodic Average Cost Method","Cost Management",14.5,"06/10 - Consultora questionou a solução oferecida pelo suporte",null,null,null,"Médio",null,null,null,null,"Processo de consignado - PAC",null,null,null,null,null],"agingFormula":true},{"id":"222","values":["leandro.cavalheiro@ninecon.com.br","23/09/2026 16:19","4-0003854335 ","n/a","n/a","n/a","n/a","BB - Error Processing Bank Return File – JGTMONTH Function","LACLS",14.320138888891961,"23/09 - Solução oferecida",null,null,null,"ALTO",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"223","values":["tania.silva@ninecon.com.br","23/09/2026 17:59","4-0003855562 ","n/a","n/a","n/a","n/a","Banco Sicoob Boleto - Erro de arquivo de remessa","LACLS",14.250694444446708,"30/09 - Em teste com o cliente",null,null,null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"224","values":["douglas.sampaio@ninecon.com.br","23/09/2026 21:48","4-0003858019 ","n/a","n/a","n/a","n/a","Domain not appearing in pick list for user role creation","Transportation",14.091666666667152,"23/09 - Foi compartilhado uma documentação, em análise com o consultor Ninecon",null,null,null,"Baixo",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"225","values":["jonatan.molossi@ninecon.com.br","24/09/2026 11:35","4-0003868494 ","n/a","n/a","n/a","n/a","No supported API to update installment due date on Debit Memos (transaction class DM)","Receivables",13.517361111109494,"24/09 - Foi compartilhado uma documentação, em análise com o consultor Ninecon",null,null,null,"Não existe",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"226","values":["bruno.petroveski@ninecon.com.br","25/09/2026 14:33","4-0003884656 ","07/10/2026 08:31","Solution Offered","4-Minimal","Never escalated","Fusion ERP – Clarification on Migration from Password-Based to Token-Based Authentication","Service",12.39375000000291,"30/09 - Solução oferecida em teste com consultor Ninecon",null,null,null,"Baixo",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"227","values":["leonardo.guilherme@ninecon.com.br","25/09/2026 17:52","4-0003886289 ","07/10/2026 13:57","Customer Working","2-Significant","Never escalated","G_LINES GROUP IS ONLY AVAILABLE IN LACLS_EXTRACTAPSPEDDATA_INCREMENTAL WITH ISV LINE CONTEXT","LACLS",12.255555555559113,"05/10 - Orientações do suporte em análise com o consultor",null,null,null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"228","values":["vanessa.breseghello@ninecon.com.br","28/09/2026 10:39","4-0003910392 ","29/09/2026 11:03","Dev Investigating","2-Significant","Never escalated","BUG:40085976: LOGLS changes CT-e access key when retransmitting a rejected document","LOGLS",9.556250000001455,"29/09 - Bug aberto ETA 16/Out",null,"16/10/2026 00:00",null,"ALTO",null,null,null,null,"CTe em nome de 3o - reenvio",null,null,null,null,null],"agingFormula":true},{"id":"229","values":["vanessa.breseghello@ninecon.com.br","29/09/2026 08:52","4-0003919984 ","02/10/2026 11:49","Dev Investigating","2-Significant","Never escalated","LOGLS BR – MDF-e Remains Rejected After Resending Shipment Following SEFAZ Rejection Correction","LOGLS",8.630555555559113,"30/09 - Bug aberto 40085976 ETA 16/out",null,"16/10/2026 00:00",null,"ALTO",null,null,null,null,"MDFe Frota Própria - quando doc rejeitado",null,null,null,null,null],"agingFormula":true},{"id":"230","values":["guilherme.bermejo@ninecon.com.br","29/09/2026 09:57","4-0003920635 ","06/10/2026 15:10","Review Update","2-Significant","Never escalated","When receiving a fiscal document that contains a delivery address, are both the Manage Legal Re…","Inventory Management",8.585416666668607,"01/10 - Em análise com o suporte",null,null,null,"Médio",null,null,null,null,null,"processo de produto em poder de terceiro - XML com tomador, fornecedor e local de entrega precisa de uma Location e de uma LRU criada dentro do ERP?",null,null,null,null],"agingFormula":true},{"id":"231","values":["vanessa.chiochetta@ninecon.com.br","29/09/2026 16:29","4-0003924316 ","06/10/2026 14:43","Review Update","2-Significant","Never escalated","Automatic Reassessment on New Qualification does not generate a new assessment","Supplier Qualification",8.313194444446708,"30/09 - Em análise com o suporte",null,null,null,"ALTO",null,null,null,"Redwood","Impossibilita usar o Redwood","Não foi testado no Classic, resposta do fornecedor",null,null,null,null],"agingFormula":true},{"id":"232","values":["guilherme.bermejo@ninecon.com.br","29/09/2026 16:32","4-0003924340 ","07/10/2026 12:02","Review Update","2-Significant","Never escalated","Unable to Allocate Charges in the Redwood Interface While the Same Process Works in the Classic…","Inventory Management",8.31111111111386,"07/10 - SR atualizada aguardando suporte",null,null,null,"ALTO",null,null,null,"Redwood",null,"Só funciona com a tela em inglês, em português não funciona, funciona na tela Clássica sem perda de funcionalidade",null,null,null,null],"agingFormula":true},{"id":"233","values":["tania.silva@ninecon.com.br","30/09/2026 15:23","4-0003934862 ","05/10/2026 15:11","Review Update","2-Significant","Never escalated","Banco Safra Brazil Localization retorna cargas BD e 00 mas valida apenas BD","LACLS",7.359027777776646,"02/10 - SR está sendo transferida para outro time",null,null,null,"Médio",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"234","values":["vera.aveiro@ninecon.com.br","01/10/2026 10:12","4-0003942154 ","07/10/2026 11:57","Solution Offered","3-Standard","Never escalated","Does not return the purchase order to create an ASN.","Inventory Management",6.57499999999709,"05/10 - Respondida pela IA, em 07/Out, o AI Agent respondeu, favor validar",null,null,null,"ALTO",null,null,null,null,"Os CFOPs 1118 e o 2118, drop ship, triangulação, funciona na tela portal do fornecedor",null,null,null,null,null],"agingFormula":true},{"id":"235","values":["vanessa.breseghello@ninecon.com.br","01/10/2026 16:04","4-0003945154 ","02/10/2026 17:25","Dev Investigating","2-Significant","Never escalated","BUG:40107137:LOGLS CT-e FDC resend action sends UNDO_REJECT_DISAGREEMENT instead of FDC_RESEND, preventing reproc","LOGLS",6.330555555556202,"02/10 - Aberto Bug 40107137 - ETA 16/Out",null,"16/10/2026 00:00",null,"ALTO",null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"236","values":["vera.aveiro@ninecon.com.br","05/10/2026 10:54","4-0003968949","05/10/2026 11:37","Customer Working","3-Standard","Never escalated","REDWOOD - In the complete inventory transactions, there is a \"tax invoice\" field, but it is always null.","Inventory Management",2.545833333329938,"05/10 - Suporte aguarda retorno do consultor Ninecon",null,null,null,"Baixo",null,null,null,null,"Não traz informações da Invoice",null,null,null,null,null],"agingFormula":true},{"id":"237","values":["leandro.cavalheiro@ninecon.com.br","05/10/2026 11:59","4-0003969622","07/10/2026 12:55","Solution Offered","2-Significant","Never escalated","Corporate Card Valid Transactions Are Not Displayed in Review Corporate Card Transactions","Expenses",2.500694444446708,"07/10 - Solução oferecida, aguardando validação do consultor",null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"238","values":["douglas.sampaio@ninecon.com.br","05/10/2026 14:50","4-0003971105","06/10/2026 19:02","Solution Offered","3-Standard","Never escalated","SHIPMENT ADD TRACKING EVENT not available for OTM Mobile planner layout","Transportation",2.381944444445253,"06/10 - Solução oferecida, aguardando validação do consultor",null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"239","values":["tania.silva@ninecon.com.br","05/10/2026 23:26","4-0003973612","07/10/2026 14:04","Dev Investigating","2-Significant","Never escalated","Banco Sicoob Pix modelos eletrônicos de transferência de arquivos bancários (CNABs)","LACLS",2.023611111108039,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"240","values":["tania.silva@ninecon.com.br","05/10/2026 23:35","4-0003973658","07/10/2026 13:17","Customer Working","2-Significant","Never escalated","Banco CAIXA Pix modelos eletrônicos de transferência de arquivos bancário","LACLS",2.0173611111094942,"07/10 - Suporte aguarda confirmação do layout bancário junto a Caixa",null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"241","values":["rosangela.nakano@ninecon.com.br","06/10/2026 08:50","4-0003978031","06/10/2026 09:57","Solution Offered","2-Significant","Never escalated","Unable to create Resource Rate using Cost Element from a Cost Element Set different from Common Set","Cost Management",1.6319444444452529,"07/10 - Solução oferecida, aguardando validação do consultor",null,null,null,"Médio",null,null,null,"Redwood","Impacta no fechamento - taxa do EPM","Na abertura do elemento de custos, não consegue abrir a taxa na tela Redwood",null,null,null,null],"agingFormula":true},{"id":"242","values":["bruno.petroveski@ninecon.com.br","06/10/2026 12:23","4-0003980186","06/10/2026 16:56","Customer Working","2-Significant","Never escalated","ODT Job-Generated COPY$_%BAD and COPY$%_LOG Tables","Data Transforms",1.484027777776646,"06/10 - Suporte informou que processo de deleção de dados está fora do domínio do suporte ",null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"243","values":["guilherme.bermejo@ninecon.com.br","06/10/2026 15:32","4-0003981632","06/10/2026 16:10","New","2-Significant","Never escalated","ASN Number Cannot Be Changed in Redwood Fiscal Document Capture","Inventory Management",1.3527777777781012,"06/10 - Em análise com o suporte",null,null,null,"ALTO",null,null,null,"Redwood",null,"Não permite editar a lista de valores. Na tela Clássica funciona com perda de funcionalidade",null,null,null,null],"agingFormula":true},{"id":"244","values":["leonardo.guilherme@ninecon.com.br","06/10/2026 17:19","4-0003982367 ","06/10/2026 18:12","Solution Offered","2-Significant","Never escalated","FDC – ERROR WHEN IMPORTING XML FOR SUPPLIERS WITH THE SAME CPF/CNPJ AND DIFFERENT STATE REGISTRATION","Inventory Management",1.2784722222204437,"06/10 - Solução oferecida, aguardando validação do consultor",null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":true},{"id":"245","values":["guilherme.bermejo@ninecon.com.br","07/10/2026 08:49","4-0003988301 ","07/10/2026 09:03","New","2-Significant","Never escalated","FDC Redwood search does not provide an exact match filter for fiscal document number","Inventory Management",null,"07/10 - Em análise com o suporte",null,null,null,"ALTO",null,null,null,"Redwood",null,"Dado só entra no cabeçalho, não entra na linha. Não funciona na Clássica também.",null,null,null,null],"agingFormula":false},{"id":"246","values":["jonatan.molossi@ninecon.com.br","07/10/2026 11:26","4-0003989742 ","07/10/2026 12:06","Solution Offered","2-Significant","Never escalated","Brazil FDG: TBC/CFOP 6118 from shipment replaced by 6923 on generated fiscal document","Oracle Fusion Tax Cloud Service",null,"07/10 - Solução oferecida, aguardando validação do consultor",null,null,null,null,null,null,null,null,null,null,null,null,null,null],"agingFormula":false}]$sr_carga_20261008$::jsonb) as item(value)
on conflict (origem_revisao, linha_origem) do nothing;

select origem_revisao, count(*) as registros
from public.sr_planilha_registros group by origem_revisao;


-- V10: visualização independente de Planilha, SR e Consolidado e logs do Analítico.

create table if not exists sr_planilha_interno.atualizacoes_portal (
  chave text primary key, aplicado_em timestamptz not null default clock_timestamp()
);
alter table sr_planilha_interno.atualizacoes_portal enable row level security;
revoke all on sr_planilha_interno.atualizacoes_portal from public, anon, authenticated;

-- Uma única migração mantém a visualização anterior. Novos usuários precisam de liberação.
do $abas_migracao$
begin
  if not exists(select 1 from sr_planilha_interno.atualizacoes_portal where chave='abas_v10') then
    update public.perfis_usuarios set permissoes = coalesce(permissoes,'{}'::jsonb)
      || case when coalesce(permissoes,'{}'::jsonb) ? 'aba_planilha' then '{}'::jsonb else '{"aba_planilha":true}'::jsonb end
      || case when coalesce(permissoes,'{}'::jsonb) ? 'aba_sr' then '{}'::jsonb else '{"aba_sr":true}'::jsonb end
      || case when coalesce(permissoes,'{}'::jsonb) ? 'aba_consolidado' then '{}'::jsonb else '{"aba_consolidado":true}'::jsonb end;
    insert into sr_planilha_interno.atualizacoes_portal(chave) values('abas_v10');
  end if;
end;
$abas_migracao$;

create or replace function sr_planilha_interno.administrador_abas()
returns boolean language sql stable security invoker set search_path='' as $$
  select exists(select 1 from public.perfis_usuarios p where p.id=(select auth.uid())
    and p.ativo is true and p.perfil='administrador'
    and (coalesce(p.mfa_obrigatorio,false) is false or (select auth.jwt()->>'aal')='aal2'));
$$;
create or replace function sr_planilha_interno.pode_visualizar_aba(p_aba text)
returns boolean language sql stable security invoker set search_path='' as $$
  select p_aba in ('planilha','sr','consolidado') and exists(
    select 1 from public.perfis_usuarios p where p.id=(select auth.uid()) and p.ativo is true
      and (coalesce(p.mfa_obrigatorio,false) is false or (select auth.jwt()->>'aal')='aal2')
      and (p.perfil='administrador' or p.permissoes->('aba_'||p_aba)='true'::jsonb)
      and (p.perfil='administrador' or p.permissoes->'inicio'='true'::jsonb
        or p.permissoes->'chamados_2025'='true'::jsonb or p.permissoes->'chamados_2026'='true'::jsonb));
$$;
create or replace function sr_planilha_interno.pode_consultar()
returns boolean language sql stable security invoker set search_path='' as $$
  select sr_planilha_interno.pode_visualizar_aba('sr') or sr_planilha_interno.pode_visualizar_aba('consolidado');
$$;
create or replace function sr_planilha_interno.pode_editar_chamado(p_ano integer)
returns boolean language sql stable security invoker set search_path='' as $$
  select sr_planilha_interno.pode_visualizar_aba('planilha') and exists(
    select 1 from public.perfis_usuarios p where p.id=(select auth.uid()) and p.ativo is true
    and (p.perfil='administrador' or (p.perfil='gestor' and p.permissoes->('chamados_'||p_ano)='true'::jsonb))
    and (coalesce(p.mfa_obrigatorio,false) is false or (select auth.jwt()->>'aal')='aal2'));
$$;
create or replace function sr_planilha_interno.pode_consultar_chamado(p_ano integer)
returns boolean language sql stable security invoker set search_path='' as $$
  select (sr_planilha_interno.pode_visualizar_aba('planilha') or sr_planilha_interno.pode_visualizar_aba('consolidado'))
    and exists(select 1 from public.perfis_usuarios p where p.id=(select auth.uid()) and p.ativo is true
      and (p.perfil='administrador' or p.permissoes->('chamados_'||p_ano)='true'::jsonb)
      and (coalesce(p.mfa_obrigatorio,false) is false or (select auth.jwt()->>'aal')='aal2'));
$$;

-- As restrições continuam válidas mesmo que exista uma política permissiva legada.
drop policy if exists sr_abas_consulta_restrita on public.sr_planilha_registros;
create policy sr_abas_consulta_restrita on public.sr_planilha_registros as restrictive for select to authenticated
using((select sr_planilha_interno.pode_consultar()));
drop policy if exists sr_abas_historico_restrito on public.sr_planilha_versoes;
create policy sr_abas_historico_restrito on public.sr_planilha_versoes as restrictive for select to authenticated
using((select sr_planilha_interno.pode_consultar()));
drop policy if exists chamados_abas_historico_restrito on public.chamados_oracle_versoes;
create policy chamados_abas_historico_restrito on public.chamados_oracle_versoes as restrictive for select to authenticated
using(sr_planilha_interno.pode_consultar_chamado(ano));

create table if not exists public.logs_abas_portal (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null, usuario_nome text, usuario_email text, perfil text,
  aba text not null check(aba in ('planilha','sr','consolidado')),
  acao text not null check(acao in ('acesso','exportacao','exportacao_original','historico','recarregamento','salvamento','permissao','erro','acesso_bloqueado')),
  origem text not null check(origem in ('navegador','banco')),
  ano integer, referencia text, quantidade integer,
  detalhes jsonb not null default '{}'::jsonb,
  registrado_em timestamptz not null default clock_timestamp()
);
create index if not exists logs_abas_data_idx on public.logs_abas_portal(registrado_em desc,id desc);
create index if not exists logs_abas_aba_data_idx on public.logs_abas_portal(aba,registrado_em desc);
create index if not exists logs_abas_usuario_data_idx on public.logs_abas_portal(usuario_id,registrado_em desc);
alter table public.logs_abas_portal enable row level security;
revoke all on public.logs_abas_portal from public,anon,authenticated;
grant select on public.logs_abas_portal to authenticated;
drop policy if exists logs_abas_apenas_administrador on public.logs_abas_portal;
create policy logs_abas_apenas_administrador on public.logs_abas_portal for select to authenticated
using((select sr_planilha_interno.administrador_abas()));
drop policy if exists logs_abas_administrador_restrito on public.logs_abas_portal;
create policy logs_abas_administrador_restrito on public.logs_abas_portal as restrictive for select to authenticated
using((select sr_planilha_interno.administrador_abas()));

-- A API registra apenas eventos de uso. Salvamentos e permissões vêm de gatilhos.
create or replace function sr_planilha_interno.registrar_evento_aba(
  p_aba text,p_acao text,p_ano integer,p_quantidade integer,p_referencia text,p_detalhes jsonb
) returns uuid language plpgsql security definer set search_path='' as $evento$
declare ator public.perfis_usuarios; resultado uuid; permitido boolean;
begin
  if auth.uid() is null then raise exception using errcode='42501',message='Autenticação necessária.'; end if;
  select * into ator from public.perfis_usuarios where id=auth.uid();
  if not found or ator.ativo is not true or (coalesce(ator.mfa_obrigatorio,false) and coalesce(auth.jwt()->>'aal','')<>'aal2') then
    raise exception using errcode='42501',message='Perfil ativo e autenticação validada são necessários.';
  end if;
  if p_aba is null or p_aba not in ('planilha','sr','consolidado') or p_acao is null
    or p_acao not in ('acesso','exportacao','exportacao_original','historico','recarregamento','erro','acesso_bloqueado') then
    raise exception 'Evento de uso inválido.';
  end if;
  if p_ano is not null and p_ano not in (2025,2026) then raise exception 'Ano inválido.'; end if;
  permitido := sr_planilha_interno.pode_visualizar_aba(p_aba)
    and (p_ano is null or ator.perfil='administrador' or ator.permissoes->('chamados_'||p_ano)='true'::jsonb);
  if not permitido and p_acao<>'acesso_bloqueado' then
    raise exception using errcode='42501',message='Visualização da aba não autorizada.';
  end if;
  if p_quantidade is not null and (p_quantidade<0 or p_quantidade>10000000) then raise exception 'Quantidade inválida.'; end if;
  if p_referencia is not null and length(p_referencia)>120 then raise exception 'Referência inválida.'; end if;
  if p_detalhes is null then p_detalhes := '{}'::jsonb; end if;
  if jsonb_typeof(p_detalhes)<>'object' or length(p_detalhes::text)>2000
    or exists(select 1 from jsonb_object_keys(p_detalhes) k where k not in ('pendentes','tipo','motivo','pagina')) then
    raise exception 'Detalhes do evento inválidos.';
  end if;
  insert into public.logs_abas_portal(usuario_id,usuario_nome,usuario_email,perfil,aba,acao,origem,ano,referencia,quantidade,detalhes)
  values(ator.id,ator.nome,ator.email,ator.perfil,p_aba,p_acao,'navegador',p_ano,p_referencia,p_quantidade,p_detalhes)
  returning id into resultado;
  return resultado;
end;
$evento$;
create or replace function public.registrar_evento_aba_portal(
  p_aba text,p_acao text,p_ano integer default null,p_quantidade integer default null,
  p_referencia text default null,p_detalhes jsonb default '{}'::jsonb
) returns uuid language sql security invoker set search_path='' as $$
  select sr_planilha_interno.registrar_evento_aba(p_aba,p_acao,p_ano,p_quantidade,p_referencia,p_detalhes);
$$;

create or replace function sr_planilha_interno.configurar_permissoes_abas(
  p_usuario_id uuid,p_permissoes jsonb,p_permissoes_esperadas jsonb
) returns jsonb language plpgsql security definer set search_path='' as $configurar$
declare atual jsonb; chave text;
begin
  if auth.uid() is null or not sr_planilha_interno.administrador_abas() then
    raise exception using errcode='42501',message='Somente Administrador ativo pode configurar as permissões.';
  end if;
  if p_permissoes is null or jsonb_typeof(p_permissoes)<>'object' then raise exception 'Permissões inválidas.'; end if;
  foreach chave in array array['aba_planilha','aba_sr','aba_consolidado'] loop
    if not (p_permissoes ? chave) or jsonb_typeof(p_permissoes->chave)<>'boolean' then raise exception 'Escolha a visualização das três abas.'; end if;
  end loop;
  select coalesce(permissoes,'{}'::jsonb) into atual from public.perfis_usuarios where id=p_usuario_id for update;
  if not found then raise exception 'Usuário não encontrado.'; end if;
  if atual is distinct from coalesce(p_permissoes_esperadas,'{}'::jsonb) then
    raise exception using errcode='40001',message='As permissões mudaram em outra sessão. Reabra Configurar antes de salvar.';
  end if;
  update public.perfis_usuarios set permissoes=p_permissoes where id=p_usuario_id;
  return p_permissoes;
end;
$configurar$;
create or replace function public.configurar_permissoes_abas_portal(
  p_usuario_id uuid,p_permissoes jsonb,p_permissoes_esperadas jsonb
) returns jsonb language sql security invoker set search_path='' as $$
  select sr_planilha_interno.configurar_permissoes_abas(p_usuario_id,p_permissoes,p_permissoes_esperadas);
$$;

create or replace function sr_planilha_interno.auditar_permissoes_abas()
returns trigger language plpgsql security definer set search_path='' as $permissoes$
declare ator public.perfis_usuarios; aba_nome text; anterior boolean; novo boolean;
begin
  if auth.uid() is null then return new; end if;
  select * into ator from public.perfis_usuarios where id=auth.uid();
  foreach aba_nome in array array['planilha','sr','consolidado'] loop
    anterior := case when tg_op='UPDATE' then coalesce(old.permissoes->('aba_'||aba_nome)='true'::jsonb,false) else false end;
    novo := coalesce(new.permissoes->('aba_'||aba_nome)='true'::jsonb,false);
    if anterior is distinct from novo then
      if not sr_planilha_interno.administrador_abas() then
        raise exception using errcode='42501',message='Somente Administrador pode alterar a visualização das abas.';
      end if;
      insert into public.logs_abas_portal(usuario_id,usuario_nome,usuario_email,perfil,aba,acao,origem,referencia,detalhes)
      values(ator.id,ator.nome,ator.email,ator.perfil,aba_nome,'permissao','banco',new.id::text,
        jsonb_build_object('usuario_alvo',new.id,'nome_alvo',new.nome,'email_alvo',new.email,'antes',anterior,'depois',novo));
    end if;
  end loop;
  return new;
end;
$permissoes$;
drop trigger if exists portal_auditar_permissoes_abas on public.perfis_usuarios;
create trigger portal_auditar_permissoes_abas after insert or update of permissoes on public.perfis_usuarios
for each row execute function sr_planilha_interno.auditar_permissoes_abas();

create or replace function public.salvar_sr_planilha_com_log(
  p_registro_id uuid,p_versao_atual integer,p_alteracoes jsonb,p_aba text
) returns public.sr_planilha_registros language plpgsql security invoker set search_path='' as $salvar$
declare resultado public.sr_planilha_registros;
begin
  if p_aba is null or p_aba not in ('sr','consolidado') or not sr_planilha_interno.pode_visualizar_aba(p_aba) then
    raise exception using errcode='42501',message='Aba não autorizada para este salvamento.';
  end if;
  perform set_config('pluma.aba_salvamento',p_aba,true);
  select * into resultado from public.salvar_sr_planilha(p_registro_id,p_versao_atual,p_alteracoes);
  return resultado;
end;
$salvar$;
create or replace function sr_planilha_interno.auditar_salvamento_aba()
returns trigger language plpgsql security definer set search_path='' as $salvo$
declare ator public.perfis_usuarios; aba_nome text; campos jsonb; ref text; v integer; ano_ref integer;
begin
  if auth.uid() is null then return new; end if;
  select * into ator from public.perfis_usuarios where id=auth.uid();
  if not found or ator.ativo is not true then raise exception using errcode='42501',message='Autor do salvamento inválido.'; end if;
  if tg_table_name='sr_planilha_registros' then
    aba_nome := nullif(current_setting('pluma.aba_salvamento',true),'');
    if aba_nome is null or aba_nome not in ('sr','consolidado') then
      aba_nome := case when sr_planilha_interno.pode_visualizar_aba('sr') then 'sr' else 'consolidado' end;
    end if;
    select coalesce(jsonb_agg(i),'[]'::jsonb) into campos from generate_series(0,24) i where new.valores->i is distinct from old.valores->i;
    ref:=new.numero_sr; v:=new.versao; ano_ref:=null;
  else
    aba_nome:='planilha'; ref:=new.numero_sr; v:=new.portal_versao; ano_ref:=new.ano;
    select coalesce(jsonb_agg(k),'[]'::jsonb) into campos
    from jsonb_object_keys(to_jsonb(new)-array['portal_versao','portal_atualizado_em','portal_atualizado_por','portal_atualizado_nome','portal_atualizado_email']) k
    where to_jsonb(new)->k is distinct from to_jsonb(old)->k;
  end if;
  insert into public.logs_abas_portal(usuario_id,usuario_nome,usuario_email,perfil,aba,acao,origem,ano,referencia,quantidade,detalhes)
  values(ator.id,ator.nome,ator.email,ator.perfil,aba_nome,'salvamento','banco',ano_ref,ref,jsonb_array_length(campos),
    jsonb_build_object('versao',v,'campos',campos,'registro_id',new.id));
  return new;
end;
$salvo$;
drop trigger if exists zz_portal_log_sr on public.sr_planilha_registros;
create trigger zz_portal_log_sr after update on public.sr_planilha_registros for each row execute function sr_planilha_interno.auditar_salvamento_aba();
drop trigger if exists zz_portal_log_planilha on public.chamados_oracle;
create trigger zz_portal_log_planilha after update on public.chamados_oracle for each row execute function sr_planilha_interno.auditar_salvamento_aba();

revoke execute on function sr_planilha_interno.administrador_abas(),sr_planilha_interno.pode_visualizar_aba(text),
 sr_planilha_interno.registrar_evento_aba(text,text,integer,integer,text,jsonb),sr_planilha_interno.configurar_permissoes_abas(uuid,jsonb,jsonb),
 sr_planilha_interno.auditar_permissoes_abas(),sr_planilha_interno.auditar_salvamento_aba(),
 public.registrar_evento_aba_portal(text,text,integer,integer,text,jsonb),public.configurar_permissoes_abas_portal(uuid,jsonb,jsonb),
 public.salvar_sr_planilha_com_log(uuid,integer,jsonb,text) from public,anon,authenticated;
grant execute on function sr_planilha_interno.administrador_abas(),sr_planilha_interno.pode_visualizar_aba(text),
 sr_planilha_interno.registrar_evento_aba(text,text,integer,integer,text,jsonb),sr_planilha_interno.configurar_permissoes_abas(uuid,jsonb,jsonb),
 public.registrar_evento_aba_portal(text,text,integer,integer,text,jsonb),public.configurar_permissoes_abas_portal(uuid,jsonb,jsonb),
 public.salvar_sr_planilha_com_log(uuid,integer,jsonb,text) to authenticated;
notify pgrst,'reload schema';

commit;


-- ATUALIZAÇÃO V11: cadastro das SRs sem correspondência no consolidado.
-- Execute TODO este arquivo no SQL Editor do projeto SUPORTE ORACLE.
-- Pré-requisito: instalação V10. Preserva os registros e o histórico existentes.
begin;

do $requisitos$
begin
  if to_regclass('public.sr_planilha_registros') is null
    or to_regclass('public.sr_planilha_versoes') is null
    or to_regclass('public.logs_abas_portal') is null
    or to_regprocedure('public.salvar_sr_planilha_com_log(uuid,integer,jsonb,text)') is null then
    raise exception 'Instale primeiro a V10 ou execute sql/INSTALAR_SR_VERSIONADA.sql para uma instalação nova.';
  end if;
end;
$requisitos$;

create index if not exists sr_planilha_revisao_numero_normalizado_idx
on public.sr_planilha_registros(origem_revisao, regexp_replace(upper(btrim(numero_sr)), '\s+', '', 'g'));

-- A regra privada é usada pela API, pela política RLS e pelo gatilho.
-- SECURITY INVOKER preserva as permissões do usuário em cada consulta.
create or replace function sr_planilha_interno.pode_criar_sr(
  p_origem_revisao text, p_linha_origem text, p_numero_sr text
) returns boolean language plpgsql stable security invoker set search_path = '' as $regra$
declare ano_ref integer;
begin
  if auth.uid() is null or not coalesce(sr_planilha_interno.pode_editar(), false)
    or p_origem_revisao is null or p_numero_sr is null or btrim(p_numero_sr) = ''
    or p_linha_origem is null or p_linha_origem !~ '^portal:(2025|2026):'
    or p_numero_sr <> regexp_replace(upper(btrim(p_numero_sr)), '\s+', '', 'g') then
    return false;
  end if;
  ano_ref := split_part(p_linha_origem, ':', 2)::integer;
  if p_linha_origem <> 'portal:' || ano_ref || ':' || p_numero_sr then return false; end if;
  if not exists(select 1 from public.perfis_usuarios p where p.id = auth.uid() and p.ativo is true
    and (p.perfil = 'administrador' or p.permissoes -> ('chamados_' || ano_ref) = 'true'::jsonb)) then
    return false;
  end if;
  return exists(select 1 from public.sr_planilha_registros r
      where r.origem_revisao = p_origem_revisao and r.linha_origem not like 'portal:%')
    and exists(select 1 from public.chamados_oracle c where c.ano = ano_ref
      and regexp_replace(upper(btrim(c.numero_sr)), '\s+', '', 'g') = p_numero_sr);
end;
$regra$;

alter table public.sr_planilha_registros enable row level security;
alter table public.sr_planilha_versoes enable row level security;
grant usage on schema public, sr_planilha_interno to authenticated;
-- Autor, datas, versão e identificador são atribuídos pelo banco.
grant insert(origem_revisao, linha_origem, numero_sr, valores, aging_calculado)
on public.sr_planilha_registros to authenticated;
drop policy if exists sr_planilha_cadastro_portal on public.sr_planilha_registros;
create policy sr_planilha_cadastro_portal on public.sr_planilha_registros for insert to authenticated
with check (not aging_calculado and sr_planilha_interno.pode_criar_sr(origem_revisao, linha_origem, numero_sr));
drop policy if exists sr_planilha_cadastro_restrito on public.sr_planilha_registros;
create policy sr_planilha_cadastro_restrito on public.sr_planilha_registros as restrictive for insert to authenticated
with check (not aging_calculado and sr_planilha_interno.pode_criar_sr(origem_revisao, linha_origem, numero_sr));

create or replace function sr_planilha_interno.validar_registro()
returns trigger language plpgsql security invoker set search_path = '' as $validar$
declare i integer;
begin
  if jsonb_typeof(new.valores) <> 'array' or jsonb_array_length(new.valores) <> 25 then
    raise exception 'O registro deve conter os 25 campos da SR.';
  end if;
  for i in 0..24 loop
    if jsonb_typeof(new.valores -> i) not in ('string', 'number', 'boolean', 'null') then
      raise exception 'Campo % com tipo inválido.', i;
    end if;
  end loop;
  if btrim(new.valores ->> 2) is distinct from new.numero_sr then
    raise exception 'O número da SR não pode ser alterado.';
  end if;
  if tg_op = 'UPDATE' then
    if auth.uid() is null or not coalesce(sr_planilha_interno.pode_editar(), false) then
      raise exception using errcode = '42501', message = 'Somente Administrador e Gestor ativos podem editar e salvar a SR.';
    end if;
    if new.id is distinct from old.id or new.origem_revisao is distinct from old.origem_revisao
      or new.linha_origem is distinct from old.linha_origem or new.numero_sr is distinct from old.numero_sr
      or new.aging_calculado is distinct from old.aging_calculado or new.criado_em is distinct from old.criado_em
      or new.valores -> 2 is distinct from old.valores -> 2 then
      raise exception 'A identificação e a origem da SR permanecem fixas.';
    end if;
    if old.aging_calculado and new.valores -> 9 is distinct from old.valores -> 9 then
      raise exception 'Aging é calculado e não pode ser editado nesta linha.';
    end if;
    if new.valores = old.valores then return null; end if;
    new.versao := old.versao + 1;
  else
    if auth.uid() is not null and (new.aging_calculado or not coalesce(
      sr_planilha_interno.pode_criar_sr(new.origem_revisao, new.linha_origem, new.numero_sr), false)) then
      raise exception using errcode = '42501', message = 'Seu perfil não permite cadastrar esta SR.';
    end if;
    new.versao := 1;
  end if;
  new.atualizado_em := clock_timestamp(); new.atualizado_por := auth.uid();
  if auth.uid() is not null then
    select p.nome, p.email into new.atualizado_nome, new.atualizado_email
    from public.perfis_usuarios p where p.id = auth.uid() and p.ativo is true;
  else
    new.atualizado_nome := null; new.atualizado_email := null;
  end if;
  return new;
end;
$validar$;

create or replace function public.criar_sr_planilha_com_log(
  p_origem_revisao text, p_numero_sr text, p_ano integer, p_alteracoes jsonb, p_aba text
) returns public.sr_planilha_registros language plpgsql security invoker set search_path = '' as $criar$
declare
  numero text; linha text; novos_valores jsonb; item record; resultado public.sr_planilha_registros;
begin
  numero := regexp_replace(upper(btrim(p_numero_sr)), '\s+', '', 'g');
  linha := 'portal:' || p_ano || ':' || numero;
  if p_aba is null or p_aba not in ('sr', 'consolidado') or p_ano is null or p_ano not in (2025, 2026)
    or not coalesce(sr_planilha_interno.pode_visualizar_aba(p_aba), false)
    or not coalesce(sr_planilha_interno.pode_criar_sr(p_origem_revisao, linha, numero), false) then
    raise exception using errcode = '42501', message = 'Somente Administrador e Gestor autorizados podem cadastrar esta SR.';
  end if;
  if p_alteracoes is null or jsonb_typeof(p_alteracoes) <> 'object' or p_alteracoes = '{}'::jsonb then
    raise exception 'Preencha pelo menos um campo da SR.';
  end if;
  -- Serializa cadastros do mesmo número na mesma revisão; nunca atualiza outro cadastro.
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(p_origem_revisao || ':' || numero, 0));
  if exists(select 1 from public.sr_planilha_registros r where r.origem_revisao = p_origem_revisao
    and regexp_replace(upper(btrim(r.numero_sr)), '\s+', '', 'g') = numero) then
    raise exception using errcode = '40001', message = 'Esta SR já tem um registro na planilha. Recarregue e revise seus rascunhos antes de salvar.';
  end if;
  select jsonb_agg('null'::jsonb order by i) into novos_valores from generate_series(0, 24) i;
  novos_valores := jsonb_set(novos_valores, array['2'], to_jsonb(numero), false);
  for item in select * from jsonb_each(p_alteracoes) loop
    if item.key !~ '^(0|[1-9]|1[0-9]|2[0-4])$' or item.key = '2' then raise exception 'Coluna inválida ou número de SR fixo.'; end if;
    if jsonb_typeof(item.value) not in ('string', 'number', 'boolean', 'null') then raise exception 'Tipo de valor inválido.'; end if;
    novos_valores := jsonb_set(novos_valores, array[item.key], item.value, false);
  end loop;
  perform set_config('pluma.aba_salvamento', p_aba, true);
  insert into public.sr_planilha_registros(origem_revisao, linha_origem, numero_sr, valores, aging_calculado)
  values(p_origem_revisao, linha, numero, novos_valores, false) returning * into resultado;
  return resultado;
exception when unique_violation then
  raise exception using errcode = '40001', message = 'Esta SR foi cadastrada por outra pessoa. Recarregue e revise seus rascunhos.';
end;
$criar$;

-- O gatilho privado é o único gravador do histórico, como na V10.
create or replace function sr_planilha_interno.registrar_versao()
returns trigger language plpgsql security definer set search_path = '' as $versao$
declare diferencas jsonb := '[]'::jsonb; anterior_em timestamptz; anterior jsonb; i integer;
begin
  if auth.uid() is not null and (new.atualizado_por is distinct from auth.uid()
    or not exists(select 1 from public.perfis_usuarios p where p.id = auth.uid() and p.ativo is true)) then
    raise exception using errcode = '42501', message = 'Autor da alteração inválido.';
  end if;
  if tg_op = 'UPDATE' and auth.uid() is null then
    raise exception using errcode = '42501', message = 'Autor da alteração inválido.';
  end if;
  for i in 0..24 loop
    anterior := null; anterior_em := null;
    if tg_op = 'UPDATE' then
      if new.valores -> i is not distinct from old.valores -> i then continue; end if;
      anterior := old.valores -> i;
      select v.alterado_em into anterior_em from public.sr_planilha_versoes v where v.registro_id = new.id
        and (v.versao = 1 or v.alteracoes @> jsonb_build_array(jsonb_build_object('coluna', i)))
        order by v.versao desc limit 1;
    elsif auth.uid() is null or new.valores -> i = 'null'::jsonb or new.valores ->> i = '' then
      continue;
    end if;
    diferencas := diferencas || jsonb_build_array(jsonb_build_object('coluna', i, 'anterior', anterior,
      'novo', new.valores -> i, 'anterior_em', anterior_em, 'novo_em', new.atualizado_em,
      'usuario_nome', new.atualizado_nome, 'usuario_email', new.atualizado_email));
  end loop;
  insert into public.sr_planilha_versoes(registro_id, versao, valores, alteracoes, acao, usuario_id, usuario_nome, usuario_email, alterado_em)
  values(new.id, new.versao, new.valores, diferencas,
    case when tg_op = 'INSERT' and auth.uid() is null then 'carga_inicial' else 'edicao' end,
    auth.uid(), new.atualizado_nome, new.atualizado_email, new.atualizado_em);
  return new;
end;
$versao$;

create or replace function sr_planilha_interno.auditar_salvamento_aba()
returns trigger language plpgsql security definer set search_path = '' as $log$
declare ator public.perfis_usuarios; aba_nome text; campos jsonb; ref text; v integer; ano_ref integer;
begin
  if auth.uid() is null then return new; end if;
  select * into ator from public.perfis_usuarios where id = auth.uid();
  if not found or ator.ativo is not true then raise exception using errcode = '42501', message = 'Autor do salvamento inválido.'; end if;
  if tg_table_name = 'sr_planilha_registros' then
    aba_nome := nullif(current_setting('pluma.aba_salvamento', true), '');
    if aba_nome is null or aba_nome not in ('sr', 'consolidado') then
      aba_nome := case when sr_planilha_interno.pode_visualizar_aba('sr') then 'sr' else 'consolidado' end;
    end if;
    if tg_op = 'INSERT' then
      select coalesce(jsonb_agg(i), '[]'::jsonb) into campos from generate_series(0, 24) i
      where new.valores -> i <> 'null'::jsonb and new.valores ->> i <> '';
    else
      select coalesce(jsonb_agg(i), '[]'::jsonb) into campos from generate_series(0, 24) i
      where new.valores -> i is distinct from old.valores -> i;
    end if;
    ref := new.numero_sr; v := new.versao;
    ano_ref := case when new.linha_origem ~ '^portal:(2025|2026):' then split_part(new.linha_origem, ':', 2)::integer else null end;
  else
    aba_nome := 'planilha'; ref := new.numero_sr; v := new.portal_versao; ano_ref := new.ano;
    select coalesce(jsonb_agg(k), '[]'::jsonb) into campos
    from jsonb_object_keys(to_jsonb(new) - array['portal_versao','portal_atualizado_em','portal_atualizado_por','portal_atualizado_nome','portal_atualizado_email']) k
    where to_jsonb(new) -> k is distinct from to_jsonb(old) -> k;
  end if;
  insert into public.logs_abas_portal(usuario_id,usuario_nome,usuario_email,perfil,aba,acao,origem,ano,referencia,quantidade,detalhes)
  values(ator.id,ator.nome,ator.email,ator.perfil,aba_nome,'salvamento','banco',ano_ref,ref,jsonb_array_length(campos),
    jsonb_build_object('versao',v,'campos',campos,'registro_id',new.id,'operacao',case when tg_op = 'INSERT' then 'cadastro' else 'edicao' end));
  return new;
end;
$log$;
drop trigger if exists zz_portal_log_sr on public.sr_planilha_registros;
create trigger zz_portal_log_sr after insert or update on public.sr_planilha_registros
for each row execute function sr_planilha_interno.auditar_salvamento_aba();

revoke execute on function sr_planilha_interno.pode_criar_sr(text,text,text),
  public.criar_sr_planilha_com_log(text,text,integer,jsonb,text) from public, anon, authenticated;
grant execute on function sr_planilha_interno.pode_criar_sr(text,text,text),
  public.criar_sr_planilha_com_log(text,text,integer,jsonb,text) to authenticated;
revoke execute on function sr_planilha_interno.validar_registro(), sr_planilha_interno.registrar_versao(),
  sr_planilha_interno.auditar_salvamento_aba() from public, anon, authenticated;
notify pgrst, 'reload schema';
commit;
select 'V11 instalada: SRs sem registro podem ser cadastradas com autoria, versões e logs.' as resultado;
